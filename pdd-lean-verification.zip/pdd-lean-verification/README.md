# The higher-order distance limit for periodic crystals

Lean 4 formalization of Conjecture 5.5 in Daniel Widdowson and Vitaliy Kurlin,
*Higher-order, generically complete, continuous, and polynomial-time invariants
of crystalline materials*, published online on 5 October 2026.
[Article and printed statement](https://doi.org/10.1007/s40314-026-03905-z)

For a full-rank periodic point set in `ℝⁿ`, fix an origin at a motif site.
An unordered choice of `h` distinct other sites has a score equal to the
arithmetic mean of the distances over the pairs of its `h + 1` vertices.
Take the `k`-th smallest score at each motif site and average them to obtain
`a(h,k)`. The theorem gives the limit of `a(h,k) / (h! k)^(1/(nh))`.

The limiting constant in lattice coordinates is
`(m^h · vol(B))^(-1/(nh))`. Here `m` is the number of sites per motif and
`B` is the unit sublevel set of the mean-distance function on the product
coordinate space `ℝ^(nh)`. In physical coordinates the product volume
changes by the `h`-th power of the cell volume, yielding the equivalent
expression `(ρ^h · vol(B_phys))^(-1/(nh))` for point density `ρ`.

The Lean model uses an invertible real linear coordinate map into Euclidean
space and one representative per motif site in the half-open unit cube.
`PDDLimit.Conjecture55` is the precise statement that is checked. The
normalization uses the `nh`-th root as in the journal version.
The formal result gives the limit with its exact constant and a bounded
additive remainder, both for each motif site and for the motif average.

## Screening and stability

The results below refer to Definitions 5.6 and 5.7, Lemma 5.8, and
Corollary 5.9 of the same article.

- [ScreeningCounterexample.lean](PDDLimit/ScreeningCounterexample.lean) derives
  the scores from the infinite integer lattice. Scaled sites are represented
  by their integer indices, and a triangle score is two thirds of its span.
- [ScreeningCertificate.lean](PDDLimit/ScreeningCertificate.lean) proves
  that the refitted joint order-two distance for the lattices Z and 2Z
  is above 0.533 at 9 columns and at most 0.533 at 10 columns. Its
  square-root bounds are exact rational inequalities. The same module
  checks an order-one counterexample to RMS monotonicity.
- [Screening.lean](PDDLimit/Screening.lean) proves monotonicity for finite
  transport with fixed baselines and unnormalized Lp or sup costs. The
  RMS bound has the factor sqrt(k/K). The maximum over orders preserves
  the corresponding inequality.
- [FittedStability.lean](PDDLimit/FittedStability.lean) proves a 2 epsilon
  bound for EMD with fitted RMS cost when a coupling has each raw entry
  error bounded by 2 epsilon on its support. It also proves a new monotonicity
  property under refitting when the transport cost is the unnormalized
  sum of squared coordinate differences. For the actual predictor in
  Definition 5.6, the multiplier used in the pointwise estimate of
  Corollary 5.9(c) is greater than 1 in the last column whenever k is at
  least 2.
- [Perturbations.lean](PDDLimit/Perturbations.lean) bounds changes in
  mean tuple distances and in the ranked values of matched, locally
  finite score lists. A periodic perturbation inducing a bijection of motif
  rows supplies the coupling for the RMS estimate.

The transport theorems use finite weighted row distributions. Their
geometry-independent hypotheses make the dependence on the coupling,
baseline, and cost explicit.

## Proof

1. [Grid.lean](PDDLimit/Grid.lean) bounds the lattice count between volumes
   of two sublevel sets with radii differing by a fixed amount.
2. [Average.lean](PDDLimit/Average.lean) proves the required norm bounds and
   permutation invariance of the mean pairwise distance.
3. [Tuples.lean](PDDLimit/Tuples.lean) identifies tuples with integer
   translations of motif choices and counts `h!` orderings per valid
   unordered selection.
4. [Collisions.lean](PDDLimit/Collisions.lean) bounds the number of tuples
   with a repeated or central site by deleting one coordinate and recording
   the collision. It proves the final theorems `conjecture55` and
   `conjecture55_limit`.
5. [Quantile.lean](PDDLimit/Quantile.lean) and [Limit.lean](PDDLimit/Limit.lean)
   invert the count asymptotic and pass to averages.
6. [BoundedError.lean](PDDLimit/BoundedError.lean) absorbs the collision
   error into a fixed shift of the counting radius and proves the
   bounded remainder.

## Build

Install [elan](https://github.com/leanprover/elan) and run these commands from
the repository root.

```sh
lake exe cache get
lake build --wfail
```

`lean-toolchain` selects Lean 4.28.0. `lakefile.toml` and
`lake-manifest.json` pin Mathlib and its dependencies. The final module
prints the axioms used by both theorems. [Audit.lean](PDDLimit/Audit.lean)
prints the corresponding results for the new theorems. The only permitted
axioms for these checks are `propext`, `Classical.choice`, and `Quot.sound`.
