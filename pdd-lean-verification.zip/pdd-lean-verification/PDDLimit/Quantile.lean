import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic

namespace PDDLimit

open Filter
open scoped Topology

/-- The k-th value encoded by a counting function, with indexing starting at 1. -/
noncomputable def quantile (count : ℝ → ℕ) (k : ℕ) : ℝ :=
  sInf {r : ℝ | 0 ≤ r ∧ k ≤ count r}

theorem root_pow (d : ℕ) (hd : d ≠ 0) {x : ℝ} (hx : 0 ≤ x) :
    (x ^ (1 / (d : ℝ))) ^ d = x := by
  rw [← Real.rpow_natCast, ← Real.rpow_mul hx]
  have hd' : (d : ℝ) ≠ 0 := by exact_mod_cast hd
  rw [div_mul_cancel₀ _ hd', Real.rpow_one]

/-- Inverting a power-law counting asymptotic. The constant (c) is chosen so that
the counting coefficient is (c^{-d}). Monotonicity handles ties in the count. -/
theorem tendsto_quantile_of_count
    {count : ℝ → ℕ} (hm : Monotone count) {d : ℕ} (hd : d ≠ 0)
    {c : ℝ} (hc : 0 < c)
    (hcount : Tendsto (fun r : ℝ => (count r : ℝ) / r ^ d) atTop (𝓝 ((c ^ d)⁻¹))) :
    Tendsto (fun k : ℕ => quantile count k / (k : ℝ) ^ (1 / (d : ℝ)))
      atTop (𝓝 c) := by
  have hd' : 0 < (d : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hd
  let root : ℕ → ℝ := fun k => (k : ℝ) ^ (1 / (d : ℝ))
  have hroot : Tendsto root atTop atTop :=
    (tendsto_rpow_atTop (one_div_pos.mpr hd')).comp tendsto_natCast_atTop_atTop
  change Tendsto (fun k : ℕ => quantile count k / root k) atTop (𝓝 c)
  have bracket (b : ℝ) (hb : 0 < b) :
      Tendsto (fun k : ℕ => (count (b * root k) : ℝ) / (k : ℝ))
        atTop (𝓝 (b ^ d * (c ^ d)⁻¹)) := by
    have hscale : Tendsto (fun k => b * root k) atTop atTop :=
      (tendsto_const_mul_atTop_of_pos hb).2 hroot
    refine (tendsto_const_nhds.mul (hcount.comp hscale)).congr' ?_
    filter_upwards [eventually_gt_atTop (0 : ℕ)] with k hk
    have hk' : (0 : ℝ) < k := by exact_mod_cast hk
    have hb' : b ^ d ≠ 0 := pow_ne_zero _ hb.ne'
    simp only [Function.comp_apply, mul_pow, root, root_pow d hd (Nat.cast_nonneg k)]
    field_simp
  rw [Metric.tendsto_nhds]
  intro ε hε
  let δ := min (ε / 2) (c / 2)
  have hδ : 0 < δ := lt_min (by linarith) (by linarith)
  have hδc : δ ≤ c / 2 := min_le_right _ _
  have hδε : δ ≤ ε / 2 := min_le_left _ _
  have hl : 0 < c - δ := by linarith
  have hu : 0 < c + δ := by linarith
  have hcp : 0 < c ^ d := pow_pos hc _
  have hpL : (c - δ) ^ d < c ^ d :=
    pow_lt_pow_left₀ (by linarith) hl.le hd
  have hpU : c ^ d < (c + δ) ^ d :=
    pow_lt_pow_left₀ (by linarith) hc.le hd
  have hL : (c - δ) ^ d * (c ^ d)⁻¹ < 1 := by
    rw [← div_eq_mul_inv, div_lt_one hcp]
    exact hpL
  have hU : 1 < (c + δ) ^ d * (c ^ d)⁻¹ := by
    rw [← div_eq_mul_inv, one_lt_div hcp]
    exact hpU
  filter_upwards [(bracket _ hl).eventually_lt_const hL,
    (bracket _ hu).eventually_const_lt hU, eventually_gt_atTop (0 : ℕ)] with k hlow hhigh hk
  have hk' : (0 : ℝ) < k := by exact_mod_cast hk
  have hr : 0 < root k := Real.rpow_pos_of_pos hk' _
  have ha : count ((c - δ) * root k) < k := by
    have := (div_lt_one hk').1 hlow
    exact_mod_cast this
  have hb : k ≤ count ((c + δ) * root k) := by
    have := (one_lt_div hk').1 hhigh
    exact_mod_cast this.le
  have hnonempty : {r : ℝ | 0 ≤ r ∧ k ≤ count r}.Nonempty :=
    ⟨_, mul_nonneg hu.le hr.le, hb⟩
  have hbdd : BddBelow {r : ℝ | 0 ≤ r ∧ k ≤ count r} := ⟨0, fun _ hx => hx.1⟩
  have hqL : (c - δ) * root k ≤ quantile count k := by
    apply le_csInf hnonempty
    intro r hr'
    by_contra! h
    exact (not_le_of_gt ha) (hr'.2.trans (hm h.le))
  have hqU : quantile count k ≤ (c + δ) * root k :=
    csInf_le hbdd ⟨mul_nonneg hu.le hr.le, hb⟩
  have h1 := (le_div_iff₀ hr).2 hqL
  have h2 := (div_le_iff₀ hr).2 hqU
  rw [Real.dist_eq, abs_lt]
  constructor <;> linarith

/-- If each unordered selection has (m) orderings, its k-th score is at
index (mk) in the ordered list. This includes ties between different selections. -/
theorem quantile_div_count (count : ℝ → ℕ) {m : ℕ} (hm : 0 < m) (k : ℕ) :
    quantile (fun r => count r / m) k = quantile count (m * k) := by
  unfold quantile
  congr 1
  ext r
  simp only [Set.mem_setOf_eq]
  rw [Nat.le_div_iff_mul_le hm, mul_comm k m]

theorem tendsto_quantile_div_count
    {count : ℝ → ℕ} (hm : Monotone count) {d m : ℕ} (hd : d ≠ 0) (hmul : 0 < m)
    {c : ℝ} (hc : 0 < c)
    (hcount : Tendsto (fun r : ℝ => (count r : ℝ) / r ^ d) atTop (𝓝 ((c ^ d)⁻¹))) :
    Tendsto (fun k : ℕ =>
      quantile (fun r => count r / m) k / ((m * k : ℕ) : ℝ) ^ (1 / (d : ℝ)))
      atTop (𝓝 c) := by
  have hscale : Tendsto (fun k : ℕ => m * k) atTop atTop := by
    apply tendsto_atTop_mono _ tendsto_id
    intro k
    exact Nat.le_mul_of_pos_left k hmul
  have := (tendsto_quantile_of_count hm hd hc hcount).comp hscale
  simpa only [Function.comp_def, quantile_div_count count hmul] using this

end PDDLimit
