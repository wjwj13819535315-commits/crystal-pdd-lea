import PDDLimit.Quantile

namespace PDDLimit
namespace Perturbation

open scoped BigOperators

theorem pair_distance_change {M I : Type*} [PseudoMetricSpace M] (x y : I → M)
    {ε : ℝ} (h : ∀ i, dist (x i) (y i) ≤ ε) (i j : I) :
    |dist (x i) (x j) - dist (y i) (y j)| ≤ 2 * ε := by
  have h₁ := dist_triangle (x i) (y i) (x j)
  have h₂ := dist_triangle (y i) (y j) (x j)
  have h₃ := dist_triangle (y i) (x i) (y j)
  have h₄ := dist_triangle (x i) (x j) (y j)
  rw [dist_comm (y j) (x j)] at h₂
  rw [dist_comm (y i) (x i)] at h₃
  exact abs_le.mpr ⟨by linarith [h i,h j], by linarith [h i,h j]⟩

/-- The average over all pairs of any chosen tuple changes by at most 2ε. -/
theorem mean_distance_change {M I : Type*} [PseudoMetricSpace M] (x y : I → M)
    {ε : ℝ} (h : ∀ i, dist (x i) (y i) ≤ ε)
    (edges : Finset (I × I)) (he : edges.Nonempty) :
    |(∑ ij ∈ edges, dist (x ij.1) (x ij.2)) / (edges.card : ℝ) -
      (∑ ij ∈ edges, dist (y ij.1) (y ij.2)) / (edges.card : ℝ)| ≤ 2 * ε := by
  have hc : 0 < (edges.card : ℝ) := by exact_mod_cast he.card_pos
  rw [← sub_div, ← Finset.sum_sub_distrib, abs_div, abs_of_pos hc]
  apply (div_le_iff₀ hc).2
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc
    _ ≤ ∑ _ij ∈ edges, 2 * ε := Finset.sum_le_sum fun ij _ =>
      pair_distance_change x y h ij.1 ij.2
    _ = _ := by simp [nsmul_eq_mul, mul_comm]

noncomputable def scoreCount {I : Type*} (score : I → ℝ) (r : ℝ) : ℕ :=
  {i | score i ≤ r}.ncard

private theorem score_shift_le {P Q : Type*} (x : P → ℝ) (y : Q → ℝ) (f : P ↪ Q)
    {δ : ℝ} (hy : ∀ r, {i | y i ≤ r}.Finite)
    (hxy : ∀ i, y (f i) ≤ x i + δ) (r : ℝ) :
    scoreCount x r ≤ scoreCount y (r+δ) :=
  Set.ncard_le_ncard_of_injOn f (fun i hi => by
    change y (f i) ≤ r + δ
    exact (hxy i).trans (add_le_add_left (show x i ≤ r from hi) δ))
    f.injective.injOn (hy _)

/-- The quantile comparison applies to infinite locally finite score lists
and counts all ties with multiplicity. -/
theorem score_quantile_change {I J : Type*} (a : I → ℝ) (b : J → ℝ) (e : I ≃ J)
    {δ : ℝ} (hδ : 0 ≤ δ) (he : ∀ i, |a i - b (e i)| ≤ δ)
    (ha : ∀ r, {i | a i ≤ r}.Finite) (hb : ∀ r, {i | b i ≤ r}.Finite)
    (k : ℕ)
    (hA : {r : ℝ | 0 ≤ r ∧ k ≤ scoreCount a r}.Nonempty)
    (hB : {r : ℝ | 0 ≤ r ∧ k ≤ scoreCount b r}.Nonempty) :
    |quantile (scoreCount a) k - quantile (scoreCount b) k| ≤ δ := by
  have cmp (c d : ℝ → ℕ) (hs : ∀ r, c r ≤ d (r+δ))
      (hc : {r : ℝ | 0 ≤ r ∧ k ≤ c r}.Nonempty) :
      quantile d k ≤ quantile c k + δ := by
    apply (sub_le_iff_le_add).1
    apply le_csInf hc
    intro r hr
    have hd : quantile d k ≤ r + δ :=
      csInf_le ⟨0, fun _ ht => ht.1⟩ ⟨add_nonneg hr.1 hδ, hr.2.trans (hs r)⟩
    linarith
  have h₁ := cmp (scoreCount a) (scoreCount b)
    (score_shift_le a b e.toEmbedding hb
      (fun i => by
        change b (e i) ≤ a i + δ
        have H := (abs_le.1 (he i)).1
        linarith)) hA
  have h₂ := cmp (scoreCount b) (scoreCount a)
    (score_shift_le b a e.symm.toEmbedding ha (fun j => by
      change a (e.symm j) ≤ b j + δ
      have H := (abs_le.1 (he (e.symm j))).2
      rw [e.apply_symm_apply] at H
      linarith)) hB
  exact abs_le.mpr ⟨by linarith, by linarith⟩

end Perturbation
end PDDLimit
