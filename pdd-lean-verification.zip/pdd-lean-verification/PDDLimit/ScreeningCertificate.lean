import PDDLimit.Screening
import PDDLimit.ScreeningCounterexample
import PDDLimit.FittedStability

namespace PDDLimit
namespace LineExample

open Screening
open scoped BigOperators

noncomputable def weight (j : ℕ) : ℝ := Real.sqrt (j + 1 : ℕ)

noncomputable def score (j : ℕ) : ℝ :=
  if j ≤ 2 then 4/3 else if j ≤ 8 then 2 else 8/3

noncomputable def fitCoeff (s : ℝ) (k : ℕ) : ℝ :=
  (∑ j ∈ Finset.range k, quantile (triangleCount s) (j + 1) * weight j) /
    (∑ j ∈ Finset.range k, ((j + 1 : ℕ) : ℝ))

noncomputable def orderOne (s : ℝ) (j : ℕ) : ℝ :=
  quantile (neighborCount s) (j + 1) - (s / 2) * ((j + 1 : ℕ) : ℝ)

/-- The factor √2 in the paper's predictor is absorbed into fitCoeff.
Its square sums are then the sum of the ranks. -/
noncomputable def orderTwo (s : ℝ) (k j : ℕ) : ℝ :=
  quantile (triangleCount s) (j + 1) - fitCoeff s k * weight j

noncomputable def jointDistance (k : ℕ) : ℝ :=
  max (supCost k (fun j => orderOne 2 j - orderOne 1 j))
      (supCost k (fun j => orderTwo 2 k j - orderTwo 1 k j))

/-- The rows used in the certificate agree with Definition 5.6's predictor
sqrt(2j), written with a zero-based column index. -/
theorem orderTwo_eq_paper_fit (s : ℝ) {k : ℕ} (hk : 0 < k) (j : ℕ) :
    orderTwo s k j =
      FittedPDA.subtractFit (fun l => Real.sqrt (2 * ((l + 1 : ℕ) : ℝ)))
        (FittedPDA.fit (fun _ : Unit => 1) k (fun l => Real.sqrt (2 * ((l + 1 : ℕ) : ℝ)))
          (fun _ l => quantile (triangleCount s) (l+1)))
        (fun _ l => quantile (triangleCount s) (l+1)) () j := by
  let x : Unit → ℕ → ℝ := fun _ l => quantile (triangleCount s) (l+1)
  have he : (fun l : ℕ => Real.sqrt (2 * ((l+1 : ℕ) : ℝ))) =
      (fun l => Real.sqrt 2 * weight l) := by
    funext l
    rw [Real.sqrt_mul (by norm_num : 0 ≤ (2 : ℝ))]
    rfl
  have hs (l : ℕ) : weight l ^ 2 = ((l + 1 : ℕ) : ℝ) :=
    Real.sq_sqrt (Nat.cast_nonneg _)
  have hB : 0 < FittedPDA.basisEnergy k weight := by
    have H : weight 0 ^ 2 ≤ FittedPDA.basisEnergy k weight :=
      Finset.single_le_sum (f := fun l => weight l ^ 2)
      (fun _ _ => sq_nonneg _) (Finset.mem_range.mpr hk)
    rw [hs 0] at H
    norm_num at H
    exact (by norm_num : (0 : ℝ) < 1).trans_le H
  have H := FittedPDA.fit_scale_predictor (fun _ : Unit => 1) k weight x hB
    (Real.sqrt 2) (ne_of_gt (Real.sqrt_pos.2 (by norm_num)))
  have hw : fitCoeff s k = FittedPDA.fit (fun _ : Unit => 1) k weight x := by
    simp only [fitCoeff, FittedPDA.fit, FittedPDA.basisEnergy, FittedPDA.dotMean,
      FittedPDA.expect, Fintype.sum_unique, one_mul, hs, x, mul_comm]
  rw [he]
  unfold orderTwo FittedPDA.subtractFit
  rw [hw, ← mul_assoc, H]

theorem jointDistance_eq_transport (k : ℕ) :
    jointDistance k =
      max (transport (fun _ : Unit => 1) (fun _ : Unit => 1)
          (fun _ _ => supCost k (fun j => orderOne 2 j - orderOne 1 j)))
        (transport (fun _ : Unit => 1) (fun _ : Unit => 1)
          (fun _ _ => supCost k (fun j => orderTwo 2 k j - orderTwo 1 k j))) := by
  rw [single_row_transport, single_row_transport]
  rfl

private theorem raw_eq (s : ℝ) (hs : 0 < s) (j : ℕ) (hj : j < 10) :
    quantile (triangleCount s) (j + 1) = s * score j := by
  rw [triangle_first_ten s hs (j + 1) (by omega)]
  unfold score
  simp only [show j + 1 ≤ 3 ↔ j ≤ 2 by omega, show j + 1 ≤ 9 ↔ j ≤ 8 by omega]

private theorem fit_eq (s : ℝ) (hs : 0 < s) (k : ℕ) (hk : k ≤ 10) :
    fitCoeff s k = s * ((∑ j ∈ Finset.range k, score j * weight j) /
      (∑ j ∈ Finset.range k, ((j + 1 : ℕ) : ℝ))) := by
  unfold fitCoeff
  rw [← mul_div_assoc, Finset.mul_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [raw_eq s hs j ((Finset.mem_range.mp hj).trans_le hk), mul_assoc]

private theorem orderTwo_diff (k j : ℕ) (hk : k ≤ 10) (hj : j < k) :
    orderTwo 2 k j - orderTwo 1 k j = score j - fitCoeff 1 k * weight j := by
  unfold orderTwo
  rw [raw_eq 2 (by norm_num) j (hj.trans_le hk), raw_eq 1 (by norm_num) j (hj.trans_le hk),
    fit_eq 2 (by norm_num) k hk, fit_eq 1 (by norm_num) k hk]
  ring

private theorem orderOne_diff (j : ℕ) :
    |orderOne 2 j - orderOne 1 j| ≤ (1/2 : ℝ) := by
  unfold orderOne
  rw [nearest_quantile 2 (by norm_num) _ (by omega),
    nearest_quantile 1 (by norm_num) _ (by omega)]
  have h₁ : (j : ℝ) + 1 ≤ 2 * (((j + 1 + 1) / 2 : ℕ) : ℝ) := by
    exact_mod_cast (show (j + 1 : ℕ) ≤ 2 * ((j + 1 + 1) / 2) by omega)
  have h₂ : 2 * (((j + 1 + 1) / 2 : ℕ) : ℝ) ≤ (j : ℝ) + 2 := by
    exact_mod_cast (show (2 : ℕ) * ((j + 1 + 1) / 2) ≤ j + 2 by omega)
  push_cast
  rw [abs_le]
  constructor <;> linarith

private def rootFloor (j : ℕ) : ℕ :=
  (#[1000000,1414213,1732050,2000000,2236067,2449489,2645751,2828427,3000000,3162277])[j]!

private noncomputable def lo (j : ℕ) : ℝ := (rootFloor j : ℝ) / 1000000
private noncomputable def hi (j : ℕ) : ℝ := ((rootFloor j : ℝ) + 1) / 1000000

private theorem root_cert (j : ℕ) (hj : j < 10) :
    lo j ≤ weight j ∧ weight j ≤ hi j := by
  constructor
  · exact (Real.le_sqrt (by unfold lo; positivity) (Nat.cast_nonneg _)).2 (by
      interval_cases j <;> norm_num [lo, rootFloor])
  · exact (Real.sqrt_le_left (by unfold hi; positivity)).2 (by
      interval_cases j <;> norm_num [hi, rootFloor])

private theorem fit_cert (k : ℕ) (hk : k = 9 ∨ k = 10) :
    (if k = 9 then (796618 : ℝ) else 805101) / 1000000 ≤ fitCoeff 1 k ∧
    fitCoeff 1 k ≤ (if k = 9 then (796620 : ℝ) else 805102) / 1000000 := by
  have hK : k ≤ 10 := by omega
  have hs (j : ℕ) : 0 ≤ score j := by unfold score; split_ifs <;> norm_num
  have hlow : (∑ j ∈ Finset.range k, score j * lo j) ≤
      ∑ j ∈ Finset.range k, score j * weight j :=
    Finset.sum_le_sum fun j hj => mul_le_mul_of_nonneg_left
      (root_cert j ((Finset.mem_range.mp hj).trans_le hK)).1 (hs j)
  have hhi : (∑ j ∈ Finset.range k, score j * weight j) ≤
      ∑ j ∈ Finset.range k, score j * hi j :=
    Finset.sum_le_sum fun j hj => mul_le_mul_of_nonneg_left
      (root_cert j ((Finset.mem_range.mp hj).trans_le hK)).2 (hs j)
  rw [fit_eq 1 (by norm_num) k hK, one_mul]
  rcases hk with rfl | rfl
  all_goals
    constructor
    · apply (le_div_iff₀ (by norm_num [Finset.sum_range_succ])).2
      refine le_trans ?_ hlow
      norm_num [Finset.sum_range_succ, score, lo, rootFloor]
    · apply (div_le_iff₀ (by norm_num [Finset.sum_range_succ])).2
      refine hhi.trans ?_
      norm_num [Finset.sum_range_succ, score, hi, rootFloor]

private theorem upper10_row (j : ℕ) (hj : j < 10) :
    |orderTwo 2 10 j - orderTwo 1 10 j| ≤ (533/1000 : ℝ) := by
  rw [orderTwo_diff 10 j (by decide) hj, abs_le]
  obtain ⟨hl,hu⟩ := fit_cert 10 (Or.inr rfl)
  simp only [show ¬ (10 : ℕ) = 9 by decide, if_false] at hl hu
  have hlo : (805101 / 1000000 : ℝ) * lo j ≤ fitCoeff 1 10 * weight j :=
    mul_le_mul hl (root_cert j hj).1 (by unfold lo; positivity) (by positivity)
  have hhi : fitCoeff 1 10 * weight j ≤ (805102 / 1000000 : ℝ) * hi j :=
    mul_le_mul hu (root_cert j hj).2 (by unfold weight; positivity) (by norm_num)
  interval_cases j <;> norm_num [score, lo, hi, rootFloor] at hlo hhi ⊢ <;>
    constructor <;> linarith

/-- Lemma 5.8 fails for its joint order-two Linfinity distance. -/
theorem refitted_screening_counterexample :
    jointDistance 10 ≤ 533/1000 ∧ 533/1000 < jointDistance 9 := by
  constructor
  · unfold jointDistance
    apply max_le
    · apply supCost_le (by norm_num)
      intro j _
      exact (orderOne_diff j).trans (by norm_num)
    · exact supCost_le (by norm_num) _ upper10_row
  · unfold jointDistance
    apply lt_of_lt_of_le _ (le_max_right _ _)
    apply lt_of_lt_of_le _ (abs_le_supCost (j := 0) (by decide) _)
    rw [orderTwo_diff 9 0 (by decide) (by decide)]
    have hu := (fit_cert 9 (Or.inl rfl)).2
    norm_num [weight, score] at hu ⊢
    exact lt_of_lt_of_le (by linarith) (le_abs_self _)

/-- RMS alone fails at order one because its denominator changes with k. -/
theorem rms_screening_counterexample :
    rmsCost 2 (fun j => orderOne 2 j - orderOne 1 j) <
      rmsCost 1 (fun j => orderOne 2 j - orderOne 1 j) := by
  have h₀ : orderOne 2 0 - orderOne 1 0 = (1/2 : ℝ) := by
    norm_num [orderOne, nearest_quantile 2 (by norm_num) 1 (by decide),
      nearest_quantile 1 (by norm_num) 1 (by decide)]
  have h₁ : orderOne 2 1 - orderOne 1 1 = 0 := by
    norm_num [orderOne, nearest_quantile 2 (by norm_num) 2 (by decide),
      nearest_quantile 1 (by norm_num) 2 (by decide)]
  unfold rmsCost
  norm_num [Finset.sum_range_succ,h₀,h₁]
  rw [show (1 / 2 : ℝ) = (2 : ℝ)⁻¹ by norm_num,
    inv_lt_inv₀ (Real.sqrt_pos.2 (by norm_num)) (by norm_num)]
  exact (Real.lt_sqrt (by norm_num)).2 (by norm_num)

end LineExample
end PDDLimit
