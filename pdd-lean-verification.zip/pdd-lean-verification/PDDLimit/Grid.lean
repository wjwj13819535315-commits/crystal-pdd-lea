import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic

namespace PDDLimit

open Filter MeasureTheory
open scoped Topology Pointwise

variable {ι : Type*} [Fintype ι]

/-- A norm-like function on a finite real coordinate space. The two comparison
constants are with respect to the coordinate sup norm. -/
structure Gauge (ι : Type*) [Fintype ι] where
  eval : (ι → ℝ) → ℝ
  lower : ℝ
  upper : ℝ
  lower_pos : 0 < lower
  upper_pos : 0 < upper
  norm_le : ∀ x, ‖x‖ ≤ lower * eval x
  le_norm : ∀ x, eval x ≤ upper * ‖x‖
  add_le : ∀ x y, eval (x + y) ≤ eval x + eval y
  smul_eq : ∀ (t : ℝ) (x : ι → ℝ), 0 ≤ t → eval (t • x) = t * eval x

def anchor (shift : ι → ℝ) (z : ι → ℤ) : ι → ℝ :=
  fun i => (z i : ℝ) + shift i

private def tile (shift : ι → ℝ) (z : ι → ℤ) : Set (ι → ℝ) :=
  Set.pi Set.univ fun i => Set.Ico (anchor shift z i) (anchor shift z i + 1)

omit [Fintype ι] in
private theorem mem_tile_iff (s : ι → ℝ) (z : ι → ℤ) (x : ι → ℝ) :
    x ∈ tile s z ↔ ∀ i, ⌊x i - s i⌋ = z i := by
  simp only [tile, Set.mem_pi, Set.mem_univ, forall_true_left, Set.mem_Ico, Int.floor_eq_iff,
    anchor]
  constructor <;> intro h i <;> specialize h i <;> constructor <;> linarith [h.1, h.2]

private theorem volume_tile (s : ι → ℝ) (z : ι → ℤ) : volume (tile s z) = 1 := by
  rw [tile, Real.volume_pi_Ico]
  simp

private theorem tile_measurable (s : ι → ℝ) (z : ι → ℤ) : MeasurableSet (tile s z) :=
  MeasurableSet.pi Set.countable_univ fun _ _ => measurableSet_Ico

omit [Fintype ι] in
private theorem tile_disjoint (s : ι → ℝ) {z w : ι → ℤ} (h : z ≠ w) :
    Disjoint (tile s z) (tile s w) := by
  rw [Set.disjoint_left]
  intro x hz hw
  exact h (funext fun i => ((mem_tile_iff s z x).mp hz i).symm.trans
    ((mem_tile_iff s w x).mp hw i))

private theorem tile_dist_le (s : ι → ℝ) (z : ι → ℤ) {x : ι → ℝ} (hx : x ∈ tile s z) :
    ‖x - anchor s z‖ ≤ 1 := by
  rw [pi_norm_le_iff_of_nonneg (by norm_num : (0 : ℝ) ≤ 1)]
  intro i
  have hi := hx i (Set.mem_univ i)
  change anchor s z i ≤ x i ∧ x i < anchor s z i + 1 at hi
  change ‖x i - anchor s z i‖ ≤ 1
  rw [Real.norm_eq_abs, abs_of_nonneg (sub_nonneg.mpr hi.1)]
  linarith [hi.2]

def sublevel (g : Gauge ι) (r : ℝ) : Set (ι → ℝ) := {x | g.eval x ≤ r}

private theorem sublevel_smul (g : Gauge ι) {r : ℝ} (hr : 0 < r) :
    sublevel g r = r • sublevel g 1 := by
  ext x
  constructor
  · intro hx
    refine ⟨r⁻¹ • x, ?_, ?_⟩
    · change g.eval (r⁻¹ • x) ≤ 1
      rw [g.smul_eq _ _ (inv_nonneg.mpr hr.le), ← div_eq_inv_mul]
      exact (div_le_one hr).2 hx
    · change r • (r⁻¹ • x) = x
      rw [smul_smul, mul_inv_cancel₀ hr.ne', one_smul]
  · rintro ⟨y, hy, rfl⟩
    change g.eval (r • y) ≤ r
    change g.eval y ≤ 1 at hy
    rw [g.smul_eq _ _ hr.le]
    simpa using mul_le_mul_of_nonneg_left hy hr.le

theorem volume_sublevel (g : Gauge ι) {r : ℝ} (hr : 0 < r) :
    volume (sublevel g r) =
      ENNReal.ofReal (r ^ Fintype.card ι) * volume (sublevel g 1) := by
  rw [sublevel_smul g hr, Measure.addHaar_smul_of_nonneg volume hr.le]
  simp

theorem volume_unit_sublevel_ne_top (g : Gauge ι) : volume (sublevel g 1) ≠ ⊤ := by
  refine ne_top_of_le_ne_top (measure_closedBall_lt_top (x := (0 : ι → ℝ))
    (r := g.lower) (μ := volume)).ne (measure_mono ?_)
  intro x hx
  change g.eval x ≤ 1 at hx
  rw [Metric.mem_closedBall, dist_zero_right]
  exact (g.norm_le x).trans (by simpa using mul_le_mul_of_nonneg_left hx g.lower_pos.le)

theorem volume_unit_sublevel_pos (g : Gauge ι) :
    0 < (volume (sublevel g 1)).toReal := by
  apply ENNReal.toReal_pos ?_ (volume_unit_sublevel_ne_top g)
  have hb : 0 < volume (Metric.ball (0 : ι → ℝ) g.upper⁻¹) :=
    Metric.measure_ball_pos volume _ (inv_pos.mpr g.upper_pos)
  apply ne_of_gt
  refine hb.trans_le (measure_mono ?_)
  intro x hx
  rw [Metric.mem_ball, dist_zero_right] at hx
  change g.eval x ≤ 1
  apply (g.le_norm x).trans
  calc
    g.upper * ‖x‖ ≤ g.upper * g.upper⁻¹ := mul_le_mul_of_nonneg_left hx.le g.upper_pos.le
    _ = 1 := mul_inv_cancel₀ g.upper_pos.ne'

theorem grid_finite (g : Gauge ι) (s : ι → ℝ) (r : ℝ) :
    {z : ι → ℤ | anchor s z ∈ sublevel g r}.Finite := by
  classical
  let w : ℝ := max 0 (g.lower * r) + ‖s‖
  have hf : (Set.pi Set.univ (fun _ : ι => Set.Icc (-⌈w⌉ : ℤ) ⌈w⌉)).Finite :=
    Set.Finite.pi fun _ => Set.finite_Icc _ _
  refine hf.subset ?_
  intro z hz i _
  change g.eval (anchor s z) ≤ r at hz
  have hbound : ‖anchor s z‖ ≤ g.lower * r :=
    (g.norm_le _).trans (mul_le_mul_of_nonneg_left hz g.lower_pos.le)
  have hcoord : ‖(z i : ℝ)‖ ≤ w := by
    have h₁ := norm_le_pi_norm (anchor s z) i
    have h₂ := norm_le_pi_norm s i
    calc
      ‖(z i : ℝ)‖ = ‖anchor s z i - s i‖ := by simp [anchor]
      _ ≤ ‖anchor s z i‖ + ‖s i‖ := norm_sub_le _ _
      _ ≤ w := add_le_add (h₁.trans (hbound.trans (le_max_right _ _))) h₂
  rw [Real.norm_eq_abs, abs_le] at hcoord
  have hw := Int.le_ceil w
  exact ⟨by exact_mod_cast ((neg_le_neg hw).trans hcoord.1),
    by exact_mod_cast (hcoord.2.trans hw)⟩

noncomputable def gridCount (g : Gauge ι) (s : ι → ℝ) (r : ℝ) : ℕ :=
  (grid_finite g s r).toFinset.card

/-- A count on one translated integer grid is bracketed by volumes of two
sublevel sets shifted by a fixed amount. -/
theorem grid_count_bounds (g : Gauge ι) (s : ι → ℝ) {r : ℝ} (hr : g.upper < r) :
    (volume (sublevel g 1)).toReal * (r - g.upper) ^ Fintype.card ι ≤ gridCount g s r ∧
    (gridCount g s r : ℝ) ≤ (volume (sublevel g 1)).toReal * (r + g.upper) ^ Fintype.card ι := by
  classical
  let indices := (grid_finite g s r).toFinset
  let tiles := ⋃ z ∈ indices, tile s z
  have htiles : volume tiles = ↑indices.card := by
    rw [show tiles = ⋃ z ∈ indices, tile s z from rfl,
      measure_biUnion_finset (fun _ _ _ _ h => tile_disjoint s h) (fun z _ => tile_measurable s z)]
    simp [volume_tile]
  have hleft : sublevel g (r - g.upper) ⊆ tiles := by
    intro x hx
    let z : ι → ℤ := fun i => ⌊x i - s i⌋
    have hmem : x ∈ tile s z := (mem_tile_iff s z x).2 fun _ => rfl
    have hd := tile_dist_le s z hmem
    have hneg : ‖anchor s z - x‖ ≤ 1 := by rwa [norm_sub_rev]
    have hg := g.add_le x (anchor s z - x)
    rw [add_sub_cancel] at hg
    have hsmall := (g.le_norm (anchor s z - x)).trans
      (by simpa using mul_le_mul_of_nonneg_left hneg g.upper_pos.le)
    change g.eval x ≤ r - g.upper at hx
    have hz : z ∈ indices := by
      change z ∈ (grid_finite g s r).toFinset
      rw [Set.Finite.mem_toFinset]
      change g.eval (anchor s z) ≤ r
      linarith
    exact Set.mem_iUnion₂.mpr ⟨z, hz, hmem⟩
  have hright : tiles ⊆ sublevel g (r + g.upper) := by
    intro x hx
    obtain ⟨z, hz, hmem⟩ := Set.mem_iUnion₂.mp hx
    have hd := tile_dist_le s z hmem
    have hg := g.add_le (anchor s z) (x - anchor s z)
    rw [add_sub_cancel] at hg
    have hsmall := (g.le_norm (x - anchor s z)).trans
      (by simpa using mul_le_mul_of_nonneg_left hd g.upper_pos.le)
    change z ∈ (grid_finite g s r).toFinset at hz
    rw [Set.Finite.mem_toFinset] at hz
    change g.eval (anchor s z) ≤ r at hz
    change g.eval x ≤ r + g.upper
    linarith
  have hoff (u : ℝ) (hu : 0 < u) :
      (volume (sublevel g u)).toReal = (volume (sublevel g 1)).toReal * u ^ Fintype.card ι :=
    by rw [volume_sublevel g hu, ENNReal.toReal_mul, ENNReal.toReal_ofReal (pow_nonneg hu.le _),
      mul_comm]
  have hfin : volume (sublevel g (r + g.upper)) ≠ ⊤ := by
    rw [volume_sublevel g (by linarith [g.upper_pos])]
    exact ENNReal.mul_ne_top ENNReal.ofReal_ne_top (volume_unit_sublevel_ne_top g)
  have hl := ENNReal.toReal_mono (by rw [htiles]; exact ENNReal.natCast_ne_top _)
    (measure_mono hleft)
  have hu := ENNReal.toReal_mono hfin (measure_mono hright)
  rw [htiles, ENNReal.toReal_natCast, hoff _ (sub_pos.mpr hr)] at hl
  rw [htiles, ENNReal.toReal_natCast, hoff _ (by linarith [g.upper_pos])] at hu
  exact ⟨hl, hu⟩

/-- The asymptotic is independent of the translation of the integer grid. -/
theorem tendsto_gridCount (g : Gauge ι) (s : ι → ℝ) :
    Tendsto (fun r : ℝ => (gridCount g s r : ℝ) / r ^ Fintype.card ι) atTop
      (𝓝 (volume (sublevel g 1)).toReal) := by
  let V := (volume (sublevel g 1)).toReal
  let d := Fintype.card ι
  have ha (a : ℝ) : Tendsto (fun r : ℝ => V * (1 + a / r) ^ d) atTop (𝓝 V) := by
    simpa using tendsto_const_nhds.mul
      ((tendsto_const_nhds.add (tendsto_id.const_div_atTop a)).pow d :
        Tendsto (fun r : ℝ => (1 + a / r) ^ d) atTop (𝓝 ((1 + 0) ^ d)))
  refine (ha (-g.upper)).squeeze' (ha g.upper) ?_ ?_
  · filter_upwards [eventually_gt_atTop g.upper] with r hr
    have hp : 0 < r := g.upper_pos.trans hr
    have he : (1 + -g.upper / r) = (r - g.upper) / r := by field_simp; ring
    rw [he, div_pow, ← mul_div_assoc]
    exact div_le_div_of_nonneg_right (grid_count_bounds g s hr).1 (pow_nonneg hp.le _)
  · filter_upwards [eventually_gt_atTop g.upper] with r hr
    have hp : 0 < r := g.upper_pos.trans hr
    have he : (1 + g.upper / r) = (r + g.upper) / r := by field_simp
    rw [he, div_pow, ← mul_div_assoc]
    exact div_le_div_of_nonneg_right (grid_count_bounds g s hr).2 (pow_nonneg hp.le _)

end PDDLimit
