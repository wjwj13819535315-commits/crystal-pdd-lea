import PDDLimit.Quantile
import Mathlib.Data.Int.Interval
import Mathlib.Data.Real.Sqrt

namespace PDDLimit
namespace LineExample

open scoped BigOperators

/-- An unordered pair of noncentral sites is represented by its increasing indices. -/
def span (x : ℤ × ℤ) : ℤ :=
  max 0 (max x.1 x.2) - min 0 (min x.1 x.2)

def pairCount (m : ℤ) : Finset (ℤ × ℤ) :=
  ((Finset.Icc (-m) m).product (Finset.Icc (-m) m)).filter
    fun x => x.1 < x.2 ∧ x.1 ≠ 0 ∧ x.2 ≠ 0 ∧ span x ≤ m

theorem mem_pairCount (m : ℤ) (x : ℤ × ℤ) :
    x ∈ pairCount m ↔ x.1 < x.2 ∧ x.1 ≠ 0 ∧ x.2 ≠ 0 ∧ span x ≤ m := by
  rw [pairCount, Finset.mem_filter, Finset.product_eq_sprod, Finset.mem_product,
    Finset.mem_Icc, Finset.mem_Icc]
  refine ⟨And.right, fun h => ⟨?_, h⟩⟩
  have hi (t : ℤ) (ha : min 0 (min x.1 x.2) ≤ t) (hb : t ≤ max 0 (max x.1 x.2)) :
      -m ≤ t ∧ t ≤ m := by
    have hl : min 0 (min x.1 x.2) ≤ 0 := min_le_left ..
    have hu : 0 ≤ max 0 (max x.1 x.2) := le_max_left ..
    have hs := h.2.2.2
    unfold span at hs
    omega
  exact ⟨hi _ ((min_le_right ..).trans (min_le_left ..))
      ((le_max_left ..).trans (le_max_right ..)),
    hi _ ((min_le_right ..).trans (min_le_right ..))
      ((le_max_right ..).trans (le_max_right ..))⟩

theorem pairCount_small (m : ℕ) (hm : 1 ≤ m ∧ m ≤ 4) :
    (pairCount (m : ℤ)).card = (#[0, 0, 3, 9, 18])[m]! := by
  obtain ⟨h₁,h₂⟩ := hm
  interval_cases m <;> decide

/-- This is the mean pairwise distance of the three vertices, for a legal pair. -/
theorem triangle_score (s : ℝ) (hs : 0 < s) (u v : ℤ) (h : u < v) :
    (|s * (u : ℝ)| + |s * (v : ℝ)| + |s * ((v : ℝ) - u)|) / 3 =
      (2 * s / 3) * (span (u, v) : ℝ) := by
  have huv : (u : ℝ) ≤ v := by exact_mod_cast h.le
  rw [abs_mul, abs_mul, abs_mul, abs_of_nonneg hs.le, abs_of_nonneg (sub_nonneg.mpr huv)]
  unfold span
  change _ = (2 * s / 3) * ((max 0 (max u v) - min 0 (min u v) : ℤ) : ℝ)
  rw [max_eq_right h.le, min_eq_left h.le, Int.cast_sub, Int.cast_max, Int.cast_min,
    Int.cast_zero]
  by_cases hu : 0 ≤ (u : ℝ)
  · rw [abs_of_nonneg hu, abs_of_nonneg (hu.trans huv), max_eq_right (hu.trans huv),
      min_eq_left hu]
    ring
  · rw [abs_of_neg (lt_of_not_ge hu), min_eq_right (le_of_not_ge hu)]
    by_cases hv : 0 ≤ (v : ℝ)
    · rw [abs_of_nonneg hv, max_eq_right hv]; ring
    · rw [abs_of_neg (lt_of_not_ge hv), max_eq_left (le_of_not_ge hv)]; ring

def triangles (s r : ℝ) : Set (ℤ × ℤ) :=
  {x | x.1 < x.2 ∧ x.1 ≠ 0 ∧ x.2 ≠ 0 ∧ (2 * s / 3) * (span x : ℝ) ≤ r}

noncomputable def triangleCount (s r : ℝ) : ℕ := (triangles s r).ncard

theorem triangles_at (s : ℝ) (hs : 0 < s) (m : ℤ) :
    triangles s ((2 * s / 3) * (m : ℝ)) = ↑(pairCount m) := by
  ext x
  simp only [triangles, Set.mem_setOf_eq, Finset.mem_coe, mem_pairCount]
  have hp : 0 < 2 * s / 3 := by positivity
  rw [mul_le_mul_iff_right₀ hp, Int.cast_le]

theorem triangleCount_at (s : ℝ) (hs : 0 < s) (m : ℤ) :
    triangleCount s ((2 * s / 3) * (m : ℝ)) = (pairCount m).card := by
  rw [triangleCount, triangles_at s hs, Set.ncard_coe_finset]

private theorem rank_from_shell
    (s : ℝ) (hs : 0 < s) (k : ℕ) (m : ℤ) (hm : 0 ≤ m)
    (hlo : (pairCount (m - 1)).card < k) (hhi : k ≤ (pairCount m).card) :
    quantile (triangleCount s) k = (2 * s / 3) * (m : ℝ) := by
  let a : ℝ := 2 * s / 3
  have ha : 0 < a := by dsimp [a]; positivity
  have hr : 0 ≤ a * (m : ℝ) := mul_nonneg ha.le (by exact_mod_cast hm)
  have hb : k ≤ triangleCount s (a * (m : ℝ)) := by
    rwa [triangleCount_at s hs]
  have hne : {r : ℝ | 0 ≤ r ∧ k ≤ triangleCount s r}.Nonempty := ⟨_, hr, hb⟩
  refine le_antisymm (csInf_le ⟨0, fun _ hx => hx.1⟩ ⟨hr,hb⟩) ?_
  apply le_csInf hne
  intro r hmem
  by_contra! hlt
  have hsub : triangles s r ⊆ ↑(pairCount (m - 1)) := by
    intro x hx
    obtain ⟨h₁,h₂,h₃,h₄⟩ := hx
    have hh : a * (span x : ℝ) < a * (m : ℝ) := h₄.trans_lt hlt
    have hi : span x < m := by exact_mod_cast (mul_lt_mul_iff_right₀ ha).mp hh
    exact (mem_pairCount _ _).2 ⟨h₁,h₂,h₃,by omega⟩
  have hcount := Set.ncard_le_ncard hsub (pairCount (m - 1)).finite_toSet
  rw [Set.ncard_coe_finset] at hcount
  exact (not_lt_of_ge (hmem.2.trans hcount)) hlo

/-- The first ten true quantiles, with all sites of the infinite chain included. -/
theorem triangle_first_ten (s : ℝ) (hs : 0 < s) (k : ℕ) (hk : 1 ≤ k ∧ k ≤ 10) :
    quantile (triangleCount s) k =
      s * (if k ≤ 3 then 4/3 else if k ≤ 9 then 2 else 8/3) := by
  split_ifs with h3 h9
  · have H := rank_from_shell s hs k 2 (by decide) (by
      have hc : (pairCount (2 - 1)).card = 0 := by decide
      omega) (by
      have hc : (pairCount 2).card = 3 := by decide
      omega)
    rw [H]
    norm_num; ring
  · have H := rank_from_shell s hs k 3 (by decide) (by
      have hc : (pairCount (3 - 1)).card = 3 := by decide
      omega) (by
      have hc : (pairCount 3).card = 9 := by decide
      omega)
    rw [H]
    norm_num; ring
  · have H := rank_from_shell s hs k 4 (by decide) (by
      have hc : (pairCount (4 - 1)).card = 9 := by decide
      omega) (by
      have hc : (pairCount 4).card = 18 := by decide
      omega)
    rw [H]
    norm_num; ring

def neighbors (s r : ℝ) : Set ℤ := {j | j ≠ 0 ∧ s * |(j : ℝ)| ≤ r}

noncomputable def neighborCount (s r : ℝ) : ℕ := (neighbors s r).ncard

private def nearBox (m : ℤ) : Finset ℤ := (Finset.Icc (-m) m).erase 0

private theorem mem_nearBox (m j : ℤ) :
    j ∈ nearBox m ↔ j ≠ 0 ∧ |j| ≤ m := by
  simp [nearBox, abs_le]

private theorem neighbors_at (s : ℝ) (hs : 0 < s) (m : ℤ) :
    neighbors s (s * (m : ℝ)) = ↑(nearBox m) := by
  ext j
  simp only [neighbors, Set.mem_setOf_eq, Finset.mem_coe, mem_nearBox,
    mul_le_mul_iff_right₀ hs, ← Int.cast_abs, Int.cast_le]

private theorem nearBox_card (m : ℕ) : (nearBox (m : ℤ)).card = 2 * m := by
  have hm : (0 : ℤ) ≤ m := by exact_mod_cast Nat.zero_le m
  have hz : (0 : ℤ) ∈ Finset.Icc (-(m : ℤ)) (m : ℤ) := by
    simp [Finset.mem_Icc, hm]
  have hcount := Int.card_Icc_of_le (a := -(m : ℤ)) (b := (m : ℤ)) (by omega)
  have hcard : (Finset.Icc (-(m : ℤ)) (m : ℤ)).card = 2 * m + 1 := by
    exact_mod_cast (show ((Finset.Icc (-(m : ℤ)) (m : ℤ)).card : ℤ) =
      ((2 * m + 1 : ℕ) : ℤ) by push_cast; omega)
  rw [nearBox, Finset.card_erase_of_mem hz, hcard]
  omega

theorem nearest_quantile (s : ℝ) (hs : 0 < s) (k : ℕ) (hk : 0 < k) :
    quantile (neighborCount s) k = s * (((k + 1) / 2 : ℕ) : ℝ) := by
  let m : ℕ := (k + 1) / 2
  have hm : 0 < m := by dsimp [m]; omega
  have hhi : k ≤ 2 * m := by dsimp [m]; omega
  have hlo : 2 * (m - 1) < k := by dsimp [m]; omega
  have hr : 0 ≤ s * (m : ℝ) := by positivity
  have hb : k ≤ neighborCount s (s * (m : ℝ)) := by
    change k ≤ (neighbors s (s * ((m : ℤ) : ℝ))).ncard
    rw [neighbors_at s hs, Set.ncard_coe_finset, nearBox_card]
    exact hhi
  have hne : {r : ℝ | 0 ≤ r ∧ k ≤ neighborCount s r}.Nonempty := ⟨_, hr, hb⟩
  refine le_antisymm (csInf_le ⟨0, fun _ hx => hx.1⟩ ⟨hr,hb⟩) ?_
  apply le_csInf hne
  intro r hmem
  by_contra! hlt
  have hsub : neighbors s r ⊆ ↑(nearBox ((m - 1 : ℕ) : ℤ)) := by
    intro j hj
    have hh : s * |(j : ℝ)| < s * (m : ℝ) := hj.2.trans_lt hlt
    have hi : |j| < (m : ℤ) := by
      have H := (mul_lt_mul_iff_right₀ hs).mp hh
      exact_mod_cast H
    exact (mem_nearBox _ _).2 ⟨hj.1, by omega⟩
  have hcount := Set.ncard_le_ncard hsub (nearBox ((m - 1 : ℕ) : ℤ)).finite_toSet
  rw [Set.ncard_coe_finset, nearBox_card] at hcount
  exact (not_lt_of_ge (hmem.2.trans hcount)) hlo

end LineExample
end PDDLimit
