import PDDLimit.Collisions

namespace PDDLimit

open Filter MeasureTheory
open scoped Topology BigOperators

/-- Fixed radius shifts for counts give a fixed additive error for quantiles. -/
theorem quantile_bounded_error {count : ℝ → ℕ} (hm : Monotone count)
    {d : ℕ} (hd : d ≠ 0) {c L : ℝ} (hc : 0 < c) (hL : 0 ≤ L)
    (hcount : ∀ᶠ r : ℝ in atTop,
      (c ^ d)⁻¹ * (r - L) ^ d ≤ (count r : ℝ) ∧
      (count r : ℝ) ≤ (c ^ d)⁻¹ * (r + L) ^ d) :
    ∀ᶠ k : ℕ in atTop,
      |quantile count k - c * (k : ℝ) ^ (1 / (d : ℝ))| ≤ L + 1 := by
  have hd' : 0 < (d : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hd
  let root : ℕ → ℝ := fun k => (k : ℝ) ^ (1 / (d : ℝ))
  let f : ℕ → ℝ := fun k => c * root k
  have ht : Tendsto f atTop atTop := (tendsto_const_mul_atTop_of_pos hc).2
    ((tendsto_rpow_atTop (one_div_pos.mpr hd')).comp tendsto_natCast_atTop_atTop)
  have hl : Tendsto (fun k => f k - (L + 1)) atTop atTop := by
    simpa only [sub_eq_add_neg] using tendsto_atTop_add_const_right _ (-(L+1)) ht
  have hu : Tendsto (fun k => f k + (L + 1)) atTop atTop :=
    tendsto_atTop_add_const_right _ _ ht
  filter_upwards [hl.eventually hcount, hu.eventually hcount,
    ht.eventually (eventually_ge_atTop (2 : ℝ))] with k hlow hhigh ht₂
  change |quantile count k - f k| ≤ L + 1
  have hpow : (c ^ d)⁻¹ * (f k) ^ d = (k : ℝ) := by
    simp only [f, root, mul_pow, root_pow d hd (Nat.cast_nonneg k), ← mul_assoc,
      inv_mul_cancel₀ (pow_ne_zero _ hc.ne'), one_mul]
  have h₁ : count (f k - (L + 1)) < k := by
    have hp : (f k - (L + 1) + L) ^ d < (f k) ^ d :=
      pow_lt_pow_left₀ (by linarith) (by linarith) hd
    have H := hlow.2.trans_lt (mul_lt_mul_of_pos_left hp (inv_pos.mpr (pow_pos hc _)))
    rw [hpow] at H
    exact_mod_cast H
  have h₂ : k ≤ count (f k + (L + 1)) := by
    have hp : (f k) ^ d ≤ (f k + (L + 1) - L) ^ d :=
      pow_le_pow_left₀ (by linarith) (by linarith) _
    have H := (mul_le_mul_of_nonneg_left hp (inv_nonneg.mpr (pow_nonneg hc.le _))).trans hhigh.1
    rw [hpow] at H
    exact_mod_cast H
  have hne : {r : ℝ | 0 ≤ r ∧ k ≤ count r}.Nonempty := ⟨_, by linarith, h₂⟩
  have ha : f k - (L + 1) ≤ quantile count k := by
    apply le_csInf hne
    intro r hr
    by_contra! hh
    exact (not_le_of_gt h₁) (hr.2.trans (hm hh.le))
  have hb : quantile count k ≤ f k + (L + 1) :=
    csInf_le ⟨0, fun _ hx => hx.1⟩ ⟨by linarith,h₂⟩
  exact abs_le.mpr ⟨by linarith,by linarith⟩

private theorem shifted_bounds {ι α : Type*} [Fintype ι] [Fintype α]
    (g : Gauge ι) (shift : α → ι → ℝ) {r : ℝ} (hr : g.upper < r) :
    let A := (Fintype.card α : ℝ) * (volume (sublevel g 1)).toReal
    A * (r - g.upper) ^ Fintype.card ι ≤ (shiftedCount g shift r : ℝ) ∧
    (shiftedCount g shift r : ℝ) ≤ A * (r + g.upper) ^ Fintype.card ι := by
  simp only [shiftedCount, Nat.cast_sum, mul_assoc]
  constructor
  · have H := Finset.sum_le_sum (s := (Finset.univ : Finset α))
      (fun a _ => (grid_count_bounds g (shift a) hr).1)
    simpa only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] using H
  · have H := Finset.sum_le_sum (s := (Finset.univ : Finset α))
      (fun a _ => (grid_count_bounds g (shift a) hr).2)
    simpa only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] using H

/-- Absorb the error from dropped collisions by increasing a fixed radius shift. -/
private theorem enlarge_shift {A U C r : ℝ} (hA : 0 < A) (hU : 0 < U)
    {d e : ℕ} (he : e < d) (hC : 0 ≤ C)
    (hr : 2 * (U + (C + 1) * 2 ^ (d - 1) / A) + 1 ≤ r) :
    A * (r - (U + (C + 1) * 2 ^ (d - 1) / A)) ^ d + C * r ^ e ≤
      A * (r - U) ^ d := by
  let T : ℝ := (C + 1) * 2 ^ (d - 1) / A
  have hT : 0 < T := by dsimp [T]; positivity
  let x := r - U
  let y := r - (U + T)
  have hy : 0 ≤ y := by dsimp [y]; change 2 * (U + T) + 1 ≤ r at hr; linarith
  have hle : y ≤ x := by dsimp [y,x]; linarith
  have hr' : 1 ≤ r := by change 2 * (U + T) + 1 ≤ r at hr; linarith
  have hx : r / 2 ≤ x := by dsimp [x]; change 2 * (U + T) + 1 ≤ r at hr; linarith
  obtain ⟨m, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt (Nat.zero_le e |>.trans_lt he))
  have hg : T * x ^ m ≤ x ^ (m + 1) - y ^ (m + 1) := by
    have H := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ hy hle m) hy
    rw [pow_succ, pow_succ]
    have H' : T = x - y := by dsimp [x,y]; ring
    rw [H']
    nlinarith only [H]
  have hs : A * T * (r / 2) ^ m = (C + 1) * r ^ m := by
    dsimp [T]
    change A * ((C + 1) * 2 ^ m / A) * (r / 2) ^ m = _
    rw [div_pow]
    field_simp
  have H := (mul_le_mul_of_nonneg_left
    (pow_le_pow_left₀ (by linarith : 0 ≤ r / 2) hx m) (mul_nonneg hA.le hT.le)).trans
      (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hg hA.le)
  rw [hs] at H
  have H' := mul_le_mul_of_nonneg_left
    (pow_le_pow_right₀ hr' (show e ≤ m by omega)) hC
  change A * y ^ (m+1) + C * r ^ e ≤ A * x ^ (m+1)
  nlinarith only [H, H', pow_nonneg (by linarith : 0 ≤ r) m]

theorem crystal_quantile_bounded_error {n h : ℕ} (S : Crystal n)
    (hn : 0 < n) (hh : 0 < h) (p : Fin n → ℝ) (hp : p ∈ S.motif) :
    ∃ B : ℝ, ∀ᶠ k : ℕ in atTop,
      |quantile (selectionCount S p h) k -
        ((orderedCoefficient S hh)⁻¹ ^ (1 / ((n * h : ℕ) : ℝ))) *
          ((h.factorial * k : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ))| ≤ B := by
  let d := n * h
  let e := n * (h - 1)
  let g := distanceGauge S.embedding hh
  let A := orderedCoefficient S hh
  let c : ℝ := A⁻¹ ^ (1 / (d : ℝ))
  have hd : d ≠ 0 := (Nat.mul_pos hn hh).ne'
  have he : e < d := Nat.mul_lt_mul_of_pos_left (by omega) hn
  have hA : 0 < A := by
    have hm : 0 < (S.motif.card : ℝ) := by exact_mod_cast S.motif_nonempty.card_pos
    exact mul_pos (pow_pos hm _) (volume_unit_sublevel_pos _)
  have hc : 0 < c := Real.rpow_pos_of_pos (inv_pos.mpr hA) _
  have hcA : (c ^ d)⁻¹ = A := by
    have H := root_pow d hd (inv_nonneg.mpr hA.le)
    change c ^ d = A⁻¹ at H
    rw [H, inv_inv]
  obtain ⟨C, hC⟩ := collision_error S p hp hh
  let C' := max C 0
  let T := (C' + 1) * 2 ^ (d - 1) / A
  let L := g.upper + T
  have hT : 0 < T := by dsimp [T,C']; positivity
  have hL : 0 ≤ L := by dsimp [L]; linarith [g.upper_pos]
  let count : ℝ → ℕ := fun r => h.factorial * selectionCount S p h r
  have hm : Monotone count := fun _ _ huv =>
    Nat.mul_le_mul_left _ (selectionCount_monotone S p hh huv)
  have hcount : ∀ᶠ r : ℝ in atTop,
      (c ^ d)⁻¹ * (r - L) ^ d ≤ (count r : ℝ) ∧
      (count r : ℝ) ≤ (c ^ d)⁻¹ * (r + L) ^ d := by
    filter_upwards [hC, eventually_ge_atTop (2 * L + 1)] with r hb hr
    have hrU : g.upper < r := by dsimp [L] at hr; linarith
    have hr' : 0 ≤ r := by linarith
    have raw : A * (r - g.upper) ^ d ≤ (allTuples S p hh r : ℝ) ∧
        (allTuples S p hh r : ℝ) ≤ A * (r + g.upper) ^ d := by
      simpa [A, d, g, allTuples, orderedCoefficient, Fintype.card_fun, Fintype.card_prod,
        Nat.mul_comm] using shifted_bounds g
          (fun (m : Fin h → S.motif) (ij : Fin h × Fin n) =>
            (m ij.1 : Fin n → ℝ) ij.2 - p ij.2) hrU
    rw [hcA]
    constructor
    · have H := enlarge_shift hA g.upper_pos he (le_max_right C 0) hr
      change A * (r - L) ^ d + C' * r ^ e ≤ A * (r - g.upper) ^ d at H
      have Hb := hb.trans (mul_le_mul_of_nonneg_right (le_max_left C 0) (pow_nonneg hr' e))
      change (allTuples S p hh r : ℝ) - count r ≤ C' * r ^ e at Hb
      linarith [raw.1]
    · have H : (count r : ℝ) ≤ allTuples S p hh r := by
        exact_mod_cast legal_count_le_all S p hh r
      refine (H.trans raw.2).trans (mul_le_mul_of_nonneg_left ?_ hA.le)
      apply pow_le_pow_left₀ (by linarith [g.upper_pos])
      dsimp [L]
      linarith
  have hscale : Tendsto (fun k : ℕ => h.factorial * k) atTop atTop := by
    apply tendsto_atTop_mono _ tendsto_id
    exact fun k => Nat.le_mul_of_pos_left k (Nat.factorial_pos _)
  refine ⟨L+1, ?_⟩
  have H := hscale.eventually (quantile_bounded_error hm hd hc hL hcount)
  have heq : (fun r => count r / h.factorial) = selectionCount S p h := by
    funext r
    simp [count, Nat.factorial_ne_zero]
  simpa only [← quantile_div_count count (Nat.factorial_pos h), heq] using H

/-- Bounded additive remainder in the actual motif-averaged quantity a(h,k). -/
theorem crystal_average_bounded_error {n h : ℕ} (S : Crystal n)
    (hn : 0 < n) (hh : 0 < h) :
    ∃ B : ℝ, ∀ᶠ k : ℕ in atTop,
      |a S h k -
        ((orderedCoefficient S hh)⁻¹ ^ (1 / ((n * h : ℕ) : ℝ))) *
          ((h.factorial * k : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ))| ≤ B := by
  classical
  let f : ℕ → ℝ := fun k =>
    ((orderedCoefficient S hh)⁻¹ ^ (1 / ((n * h : ℕ) : ℝ))) *
      ((h.factorial * k : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ))
  have H (p : S.motif) : ∃ B : ℝ, ∀ᶠ k : ℕ in atTop,
      |quantile (selectionCount S p h) k - f k| ≤ B :=
    crystal_quantile_bounded_error S hn hh p p.property
  choose B HB using H
  let B' : ℝ := ∑ p : S.motif, |B p|
  refine ⟨B', ?_⟩
  filter_upwards [Filter.eventually_all.mpr HB] with k hk
  have hc : 0 < (S.motif.card : ℝ) := by exact_mod_cast S.motif_nonempty.card_pos
  have hes : a S h k - f k =
      (∑ p ∈ S.motif, (quantile (selectionCount S p h) k - f k)) / (S.motif.card : ℝ) := by
    simp only [a, Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul]
    field_simp
  change |a S h k - f k| ≤ B'
  rw [hes, abs_div, abs_of_pos hc]
  apply (div_le_iff₀ hc).2
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc
    _ ≤ ∑ _p ∈ S.motif, B' := Finset.sum_le_sum fun p hp =>
      (hk ⟨p,hp⟩).trans ((le_abs_self _).trans
        (Finset.single_le_sum (f := fun q : S.motif => |B q|)
          (fun _ _ => abs_nonneg _) (Finset.mem_univ (⟨p,hp⟩ : S.motif))))
    _ = _ := by simp [nsmul_eq_mul, mul_comm]

end PDDLimit
