import PDDLimit.Limit
import Mathlib.Analysis.InnerProductSpace.PiL2

namespace PDDLimit

open Filter MeasureTheory
open scoped Topology BigOperators

/-- A full-rank periodic crystal, written in lattice coordinates. Motif
coordinates are representatives in the half-open fundamental cube. -/
structure Crystal (n : ℕ) where
  embedding : (Fin n → ℝ) ≃L[ℝ] EuclideanSpace ℝ (Fin n)
  motif : Finset (Fin n → ℝ)
  motif_nonempty : motif.Nonempty
  motif_representatives : ∀ p ∈ motif, ∀ i, p i ∈ Set.Ico (0 : ℝ) 1

variable {n : ℕ}

/-- Coordinates of the sites in the infinite crystal. Applying the embedding
gives their physical positions. -/
def sites (S : Crystal n) : Set (Fin n → ℝ) :=
  {x | ∃ p ∈ S.motif, ∃ z : Fin n → ℤ, x = anchor p z}

/-- One representative of each unordered h-element selection. The existential
enumeration defines its score, without choosing an ordering on the sites. -/
def selections (S : Crystal n) (p : Fin n → ℝ) (h : ℕ) (r : ℝ) :
    Set (Finset (Fin n → ℝ)) :=
  {A | p ∉ A ∧ A.card = h ∧ (↑A : Set (Fin n → ℝ)) ⊆ sites S ∧
    ∃ enumerate : Fin h ≃ A,
      meanDistance S.embedding (fun ij => (enumerate ij.1 : Fin n → ℝ) ij.2 - p ij.2) ≤ r}

noncomputable def selectionCount (S : Crystal n) (p : Fin n → ℝ) (h : ℕ)
    (r : ℝ) : ℕ :=
  (selections S p h r).ncard

/-- The average of the k-th scores over the motif, as in Definition 3.1. -/
noncomputable def a (S : Crystal n) (h k : ℕ) : ℝ :=
  (∑ p ∈ S.motif, quantile (selectionCount S p h) k) / (S.motif.card : ℝ)

/-- Conjecture 5.5 of Widdowson and Kurlin (DOI 10.1007/s40314-026-03905-z). -/
def Conjecture55 : Prop :=
  ∀ (n : ℕ) (_ : 0 < n) (S : Crystal n) (h : ℕ), 2 ≤ h →
    ∃ L : ℝ, Tendsto (fun k : ℕ =>
      a S h k / ((h.factorial * k : ℕ) : ℝ) ^ (1 / (n * h : ℕ) : ℝ))
      atTop (𝓝 L)

/-- Volume measured in product lattice coordinates times the number of
motif choices. This equals the physical volume multiplied by density^h. -/
noncomputable def orderedCoefficient (S : Crystal n) {h : ℕ} (hh : 0 < h) : ℝ :=
  (S.motif.card : ℝ) ^ h *
    (volume (sublevel (distanceGauge S.embedding hh) 1)).toReal

/-- Ordered tuples from all motif shifts, prior to removing coincidences. -/
noncomputable def allTuples (S : Crystal n) (p : Fin n → ℝ) {h : ℕ} (hh : 0 < h)
    (r : ℝ) : ℕ :=
  shiftedCount (distanceGauge S.embedding hh)
    (fun (m : Fin h → S.motif) (ij : Fin h × Fin n) => (m ij.1 : Fin n → ℝ) ij.2 - p ij.2) r

theorem tendsto_allTuples (S : Crystal n) (p : Fin n → ℝ) {h : ℕ} (hh : 0 < h) :
    Tendsto (fun r : ℝ => (allTuples S p hh r : ℝ) / r ^ (n * h))
      atTop (𝓝 (orderedCoefficient S hh)) := by
  simpa [allTuples, orderedCoefficient, Fintype.card_fun, Fintype.card_prod, Nat.mul_comm]
    using tendsto_shiftedCount (distanceGauge S.embedding hh)
      (fun (m : Fin h → S.motif) (ij : Fin h × Fin n) => (m ij.1 : Fin n → ℝ) ij.2 - p ij.2)

/-- Reduction of the printed conjecture to the correspondence between
unordered selections and injective tuples, with a lower-order collision count. -/
theorem conjecture55_of_collision_bound
    (n : ℕ) (hn : 0 < n) (S : Crystal n) (h : ℕ) (hh : 0 < h)
    (hmono : ∀ p ∈ S.motif, Monotone (selectionCount S p h))
    (hsub : ∀ p ∈ S.motif, ∀ᶠ r : ℝ in atTop,
      h.factorial * selectionCount S p h r ≤ allTuples S p hh r)
    (hbad : ∀ p ∈ S.motif, ∃ C : ℝ, ∀ᶠ r : ℝ in atTop,
      (allTuples S p hh r : ℝ) - (h.factorial * selectionCount S p h r : ℕ) ≤
        C * r ^ (n * (h - 1))) :
    Tendsto (fun k : ℕ =>
      a S h k / ((h.factorial * k : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ)))
      atTop (𝓝 ((orderedCoefficient S hh)⁻¹ ^ (1 / ((n * h : ℕ) : ℝ)))) := by
  classical
  let d := n * h
  let A := orderedCoefficient S hh
  let c : ℝ := A⁻¹ ^ (1 / (d : ℝ))
  have hd : d ≠ 0 := (Nat.mul_pos hn hh).ne'
  have hm : 0 < S.motif.card := S.motif_nonempty.card_pos
  have hm' : 0 < (S.motif.card : ℝ) := by exact_mod_cast hm
  have hA : 0 < A := mul_pos (pow_pos hm' _) (volume_unit_sublevel_pos _)
  have hc : 0 < c := Real.rpow_pos_of_pos (inv_pos.mpr hA) _
  have hcpow : c ^ d = A⁻¹ := root_pow d hd (inv_nonneg.mpr hA.le)
  have hrow (p : Fin n → ℝ) (hp : p ∈ S.motif) :
      Tendsto (fun k : ℕ =>
        quantile (selectionCount S p h) k /
          ((h.factorial * k : ℕ) : ℝ) ^ (1 / (d : ℝ))) atTop (𝓝 c) := by
    let ordered : ℝ → ℕ := fun r => h.factorial * selectionCount S p h r
    obtain ⟨C, hC⟩ := hbad p hp
    have he : n * (h - 1) < d := Nat.mul_lt_mul_of_pos_left (by omega) hn
    have hkeep := tendsto_after_deleting he (tendsto_allTuples S p hh) (hsub p hp) hC
    have hlim : Tendsto (fun r : ℝ => (ordered r : ℝ) / r ^ d) atTop
        (𝓝 ((c ^ d)⁻¹)) := by
      simpa only [hcpow, inv_inv] using hkeep
    have ho : Monotone ordered := fun _ _ huv =>
      Nat.mul_le_mul_left _ (hmono p hp huv)
    have H := tendsto_quantile_div_count ho hd (Nat.factorial_pos h) hc hlim
    have heq : (fun r => ordered r / h.factorial) = selectionCount S p h := by
      funext r
      simp [ordered, Nat.factorial_ne_zero]
    rwa [heq] at H
  have hs := tendsto_finset_sum (s := S.motif) hrow
  have H := hs.div_const (S.motif.card : ℝ)
  simp only [Finset.sum_const, nsmul_eq_mul] at H
  rw [mul_comm (S.motif.card : ℝ), mul_div_cancel_right₀ _ hm'.ne'] at H
  convert H using 1
  ext k
  simp only [a, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro p _
  dsimp [d]
  ring

end PDDLimit
