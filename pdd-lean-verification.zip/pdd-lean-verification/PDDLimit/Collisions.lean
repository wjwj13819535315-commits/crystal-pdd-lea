import PDDLimit.Tuples
import Mathlib.Data.Int.Interval
import Mathlib.Data.Fin.SuccPred

namespace PDDLimit

open Filter
open scoped Topology

variable {n : ℕ}

private abbrev IntRange (M : ℤ) := (Set.Icc (-M) M : Set ℤ)
private abbrev Box (S : Crystal n) (M : ℤ) := (Fin n → IntRange M) × S.motif

private def boxKey (S : Crystal n) {M : ℤ} (x : Box S M) : SiteKey S :=
  (fun j => (x.1 j : ℤ), x.2)

private theorem key_in_range (S : Crystal n) {h : ℕ} (hh : 0 < h)
    (p : Fin n → ℝ) (hp : p ∈ S.motif) (r : ℝ) (x : candidates S p h r)
    (i : Fin h) (j : Fin n) :
    (x.val i).1 j ∈ IntRange ⌈(distanceGauge S.embedding hh).lower * r + 1⌉ := by
  let g := distanceGauge S.embedding hh
  let M : ℤ := ⌈g.lower * r + 1⌉
  let y : Fin h × Fin n → ℝ := fun ij => point S (x.val ij.1) ij.2 - p ij.2
  have hscore : g.eval y ≤ r := x.property
  have hn : ‖y‖ ≤ g.lower * r :=
    (g.norm_le y).trans (mul_le_mul_of_nonneg_left hscore g.lower_pos.le)
  have hcoord := (norm_le_pi_norm y (i,j)).trans hn
  rw [Real.norm_eq_abs, abs_le] at hcoord
  have hm := S.motif_representatives (x.val i).2 (x.val i).2.property j
  have hp' := S.motif_representatives p hp j
  have hceil : g.lower * r + 1 ≤ (M : ℝ) := Int.le_ceil _
  change -M ≤ (x.val i).1 j ∧ (x.val i).1 j ≤ M
  change -(g.lower * r) ≤ ((x.val i).1 j : ℝ) + (x.val i).2.val j - p j ∧
    ((x.val i).1 j : ℝ) + (x.val i).2.val j - p j ≤ g.lower * r at hcoord
  exact ⟨by exact_mod_cast (show -(M : ℝ) ≤ ((x.val i).1 j : ℝ) by
    linarith [hcoord.1, hm.2, hp'.1]),
    by exact_mod_cast (show ((x.val i).1 j : ℝ) ≤ (M : ℝ) by
      linarith [hcoord.2, hm.1, hp'.2])⟩

private abbrev Collision (S : Crystal n) (p : Fin n → ℝ) (h : ℕ) (r : ℝ) :=
  (candidates S p h r \ legalCandidates S p h r : Set (Fin h → SiteKey S))

private abbrev Tag (h : ℕ) := Fin h × Option (Fin h)

private def target (S : Crystal n) {h : ℕ} (p : Fin n → ℝ)
    (x : Fin h → SiteKey S) : Option (Fin h) → Fin n → ℝ
  | none => p
  | some j => point S (x j)

private theorem collision_tag (S : Crystal n) {h : ℕ} (p : Fin n → ℝ) (r : ℝ)
    (x : Collision S p h r) :
    ∃ t : Tag h, t.2 ≠ some t.1 ∧ point S (x.val t.1) = target S p x.val t.2 := by
  classical
  have hn : ¬legal S p x.val := fun hh => x.property.2 ⟨x.property.1, hh⟩
  by_cases hi : Function.Injective x.val
  · have he : ¬∀ i, point S (x.val i) ≠ p := fun e => hn ⟨hi,e⟩
    push_neg at he
    obtain ⟨i, he⟩ := he
    exact ⟨(i,none), by simp, he⟩
  · unfold Function.Injective at hi
    push_neg at hi
    obtain ⟨i,j,hij,hne⟩ := hi
    exact ⟨(i,some j), by simpa [eq_comm] using hne, congrArg (point S) hij⟩

private theorem collision_bound (S : Crystal n) (p : Fin n → ℝ)
    (hp : p ∈ S.motif) (h : ℕ) (r : ℝ) (hr : 1 ≤ r) :
    ((Collision S p (h + 1) r).ncard : ℝ) ≤
      ((Fintype.card (Tag (h + 1)) : ℝ) *
        ((S.motif.card : ℝ) *
          (2 * (distanceGauge S.embedding (Nat.succ_pos h)).lower + 5) ^ n) ^ h) *
        r ^ (n * h) := by
  classical
  let hh := Nat.succ_pos h
  let g := distanceGauge S.embedding hh
  let M : ℤ := ⌈g.lower * r + 1⌉
  letI := ((candidates_finite S p hh r).subset
    (show Collision S p (h + 1) r ⊆ candidates S p (h + 1) r
      from Set.diff_subset)).fintype
  let tag (x : Collision S p (h + 1) r) := Classical.choose (collision_tag S p r x)
  have htag (x : Collision S p (h + 1) r) :
      (tag x).2 ≠ some (tag x).1 ∧
        point S (x.val (tag x).1) = target S p x.val (tag x).2 :=
    Classical.choose_spec (collision_tag S p r x)
  let record (x : Collision S p (h + 1) r) (i : Fin (h + 1)) : Box S M :=
    (fun j => ⟨(x.val i).1 j, key_in_range S hh p hp r ⟨x.val,x.property.1⟩ i j⟩,
      (x.val i).2)
  let encode (x : Collision S p (h + 1) r) : Tag (h + 1) × (Fin h → Box S M) :=
    (tag x, fun j => record x ((tag x).1.succAbove j))
  have henc : Function.Injective encode := by
    intro x y heq
    have ht : tag x = tag y := congrArg Prod.fst heq
    have vals (i : Fin (h + 1)) (hi : i ≠ (tag x).1) : x.val i = y.val i := by
      obtain ⟨j, hj⟩ := Fin.exists_succAbove_eq hi
      have H := congrFun (congrArg Prod.snd heq) j
      change record x ((tag x).1.succAbove j) = record y ((tag y).1.succAbove j) at H
      rw [← ht, hj] at H
      exact congrArg (boxKey S) H
    apply Subtype.ext
    funext i
    by_cases hi : i = (tag x).1
    · have hx := (htag x).2
      have hy := (htag y).2
      rw [← ht] at hy
      rw [hi]
      apply point_injective S
      rw [hx, hy]
      cases hj : (tag x).2 with
      | none => rfl
      | some j =>
        have hne : j ≠ (tag x).1 := fun hj' => (htag x).1 (hj.trans (congrArg some hj'))
        change point S (x.val j) = point S (y.val j)
        rw [vals j hne]
    · exact vals i hi
  have hcount := Fintype.card_le_of_injective encode henc
  have hM : 0 ≤ M := by
    apply Int.ceil_nonneg
    linarith [mul_nonneg g.lower_pos.le (show 0 ≤ r by linarith)]
  have hM' : 0 ≤ (M : ℝ) := by exact_mod_cast hM
  have hI : (Fintype.card (IntRange M) : ℝ) = 2 * (M : ℝ) + 1 := by
    have hx : (Fintype.card (IntRange M) : ℤ) = M + 1 - (-M) :=
      Int.card_fintype_Icc_of_le (-M) M (by omega)
    rw [show M + 1 - (-M) = 2 * M + 1 by ring] at hx
    exact_mod_cast hx
  have hR : (Fintype.card (IntRange M) : ℝ) ≤ (2 * g.lower + 5) * r := by
    rw [hI]
    have hceil : (M : ℝ) < g.lower * r + 1 + 1 := Int.ceil_lt_add_one _
    nlinarith
  have hbox : (Fintype.card (Box S M) : ℝ) ≤
      (S.motif.card : ℝ) * ((2 * g.lower + 5) * r) ^ n := by
    simp only [Fintype.card_prod, Fintype.card_fun, Fintype.card_fin,
      Fintype.card_coe, Nat.cast_mul, Nat.cast_pow]
    rw [mul_comm]
    gcongr
  have hcast : ((Collision S p (h + 1) r).ncard : ℝ) ≤
      (Fintype.card (Tag (h + 1)) : ℝ) * (Fintype.card (Box S M) : ℝ) ^ h := by
    rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card]
    exact_mod_cast (show Fintype.card (Collision S p (h+1) r) ≤
      Fintype.card (Tag (h+1)) * Fintype.card (Box S M) ^ h by simpa using hcount)
  refine hcast.trans ?_
  calc
    _ ≤ (Fintype.card (Tag (h + 1)) : ℝ) *
        ((S.motif.card : ℝ) * ((2 * g.lower + 5) * r) ^ n) ^ h := by gcongr
    _ = _ := by simp only [← pow_mul, mul_pow, g]; ring

theorem legal_count_le_all (S : Crystal n) (p : Fin n → ℝ) {h : ℕ} (hh : 0 < h) (r : ℝ) :
    h.factorial * selectionCount S p h r ≤ allTuples S p hh r := by
  rw [← legalCandidates_ncard S p hh, ← candidates_ncard S p hh]
  exact Set.ncard_le_ncard (fun _ hx => hx.1) (candidates_finite S p hh r)

theorem collision_error (S : Crystal n) (p : Fin n → ℝ) (hp : p ∈ S.motif)
    {h : ℕ} (hh : 0 < h) :
    ∃ C : ℝ, ∀ᶠ r : ℝ in atTop,
      (allTuples S p hh r : ℝ) - (h.factorial * selectionCount S p h r : ℕ) ≤
        C * r ^ (n * (h - 1)) := by
  obtain ⟨h, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hh.ne'
  refine ⟨(Fintype.card (Tag (h + 1)) : ℝ) *
    ((S.motif.card : ℝ) * (2 * (distanceGauge S.embedding hh).lower + 5) ^ n) ^ h, ?_⟩
  filter_upwards [eventually_ge_atTop (1 : ℝ)] with r hr
  rw [← legalCandidates_ncard S p hh, ← candidates_ncard S p hh]
  have hf := candidates_finite S p hh r
  have hle : legalCandidates S p (h+1) r ⊆ candidates S p (h+1) r := fun _ hx => hx.1
  have hsub := Set.ncard_le_ncard hle hf
  change (↑((candidates S p (h+1) r).ncard) : ℝ) -
    ↑((legalCandidates S p (h+1) r).ncard) ≤ _
  rw [← Nat.cast_sub hsub, ← Set.ncard_diff hle (hf.subset hle)]
  simpa using collision_bound S p hp h r hr

/-- The full limiting formula for the printed conjecture. -/
theorem conjecture55_limit (S : Crystal n) (hn : 0 < n) {h : ℕ} (hh : 2 ≤ h) :
    Tendsto (fun k : ℕ =>
      a S h k / ((h.factorial * k : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ)))
      atTop (𝓝 ((orderedCoefficient S (show 0 < h by omega))⁻¹ ^
        (1 / ((n * h : ℕ) : ℝ)))) := by
  have hp : 0 < h := by omega
  exact conjecture55_of_collision_bound n hn S h hp
    (fun p _ => selectionCount_monotone S p hp)
    (fun p _ => Eventually.of_forall (legal_count_le_all S p hp))
    (fun p hp' => collision_error S p hp' hp)

theorem conjecture55 : Conjecture55 :=
  fun _ hn S _ hh => ⟨_, conjecture55_limit S hn hh⟩

#print axioms conjecture55
#print axioms conjecture55_limit

end PDDLimit
