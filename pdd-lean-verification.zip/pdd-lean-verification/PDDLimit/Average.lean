import PDDLimit.Grid

namespace PDDLimit

open scoped BigOperators

variable {n h : ℕ} {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- The origin followed by the h displacements, in the Euclidean space of sites. -/
def vertices (e : (Fin n → ℝ) ≃L[ℝ] E) (x : Fin h × Fin n → ℝ) : Fin (h + 1) → E :=
  Fin.cases 0 (fun i => e (fun j => x (i, j)))

/-- The mean over all unordered pairs equals the sum over ordered pairs divided
by h(h+1). Diagonal pairs have distance zero. -/
noncomputable def meanDistance (e : (Fin n → ℝ) ≃L[ℝ] E)
    (x : Fin h × Fin n → ℝ) : ℝ :=
  (∑ i, ∑ j, ‖vertices e x i - vertices e x j‖) / ((h : ℝ) * (h + 1))

private def extendPermutation (π : Equiv.Perm (Fin h)) : Equiv.Perm (Fin (h + 1)) where
  toFun := Fin.cases 0 (fun i => (π i).succ)
  invFun := Fin.cases 0 (fun i => (π.symm i).succ)
  left_inv i := Fin.cases (by simp) (fun j => by simp) i
  right_inv i := Fin.cases (by simp) (fun j => by simp) i

theorem meanDistance_reindex (e : (Fin n → ℝ) ≃L[ℝ] E)
    (x : Fin h × Fin n → ℝ) (π : Equiv.Perm (Fin h)) :
    meanDistance e (fun ij => x (π ij.1, ij.2)) = meanDistance e x := by
  have hx (i : Fin (h + 1)) :
      vertices e (fun ij => x (π ij.1, ij.2)) i =
        vertices e x (extendPermutation π i) := by
    refine Fin.cases ?_ (fun j => ?_) i <;> simp [vertices, extendPermutation]
  unfold meanDistance
  simp_rw [hx]
  congr 1
  have H (i : Fin (h + 1)) :
      (∑ j : Fin (h + 1), ‖vertices e x i - vertices e x (extendPermutation π j)‖) =
        ∑ j : Fin (h + 1), ‖vertices e x i - vertices e x j‖ :=
    Equiv.sum_comp (extendPermutation π) (fun j => ‖vertices e x i - vertices e x j‖)
  simp_rw [H]
  exact Equiv.sum_comp (extendPermutation π)
    (fun i => ∑ j : Fin (h + 1), ‖vertices e x i - vertices e x j‖)

private theorem vertices_add (e : (Fin n → ℝ) ≃L[ℝ] E)
    (x y : Fin h × Fin n → ℝ) (i : Fin (h + 1)) :
    vertices e (x + y) i = vertices e x i + vertices e y i := by
  refine Fin.cases ?_ (fun j => ?_) i
  · simp [vertices]
  · exact e.map_add _ _

private theorem vertices_smul (e : (Fin n → ℝ) ≃L[ℝ] E)
    (t : ℝ) (x : Fin h × Fin n → ℝ) (i : Fin (h + 1)) :
    vertices e (t • x) i = t • vertices e x i := by
  refine Fin.cases ?_ (fun j => ?_) i
  · simp [vertices]
  · exact e.map_smul t _

private theorem vertices_norm_le (e : (Fin n → ℝ) ≃L[ℝ] E)
    (x : Fin h × Fin n → ℝ) (i : Fin (h + 1)) :
    ‖vertices e x i‖ ≤ ‖e.toContinuousLinearMap‖ * ‖x‖ := by
  refine Fin.cases ?_ (fun j => ?_) i
  · simp only [vertices, Fin.cases_zero, norm_zero]
    positivity
  · change ‖e (fun k => x (j, k))‖ ≤ _
    apply (e.toContinuousLinearMap.le_opNorm _).trans
    gcongr
    exact (pi_norm_le_iff_of_nonneg (norm_nonneg x)).2
      (fun k => norm_le_pi_norm x (j, k))

private theorem mean_nonneg (e : (Fin n → ℝ) ≃L[ℝ] E)
    (x : Fin h × Fin n → ℝ) : 0 ≤ meanDistance e x := by
  unfold meanDistance
  positivity

noncomputable def distanceGauge (e : (Fin n → ℝ) ≃L[ℝ] E) (hh : 0 < h) :
    Gauge (Fin h × Fin n) := by
  classical
  let den : ℝ := (h : ℝ) * (h + 1)
  have hden : 0 < den := by dsimp [den]; positivity
  refine {
    eval := meanDistance e
    lower := (‖e.symm.toContinuousLinearMap‖ + 1) * den
    upper := 2 * (‖e.toContinuousLinearMap‖ + 1) * (h + 1 : ℝ) ^ 2 / den
    lower_pos := by positivity
    upper_pos := by positivity
    norm_le := ?_
    le_norm := ?_
    add_le := ?_
    smul_eq := ?_ }
  · intro x
    have hnon : 0 ≤ (‖e.symm.toContinuousLinearMap‖ + 1) * den * meanDistance e x :=
      mul_nonneg (by positivity) (mean_nonneg e x)
    apply (pi_norm_le_iff_of_nonneg hnon).2
    rintro ⟨i, j⟩
    let v : Fin n → ℝ := fun k => x (i, k)
    let a := e v
    have hpart : ‖a‖ ≤ ∑ k, ∑ l, ‖vertices e x k - vertices e x l‖ := by
      calc
        ‖a‖ = ‖vertices e x i.succ - vertices e x 0‖ := by simp [a, v, vertices]
        _ ≤ ∑ l, ‖vertices e x i.succ - vertices e x l‖ :=
          Finset.single_le_sum (f := fun l : Fin (h + 1) =>
            ‖vertices e x i.succ - vertices e x l‖)
            (fun _ _ => norm_nonneg _) (Finset.mem_univ (0 : Fin (h+1)))
        _ ≤ _ := Finset.single_le_sum
          (f := fun k : Fin (h + 1) => ∑ l, ‖vertices e x k - vertices e x l‖)
          (fun _ _ => Finset.sum_nonneg fun _ _ => norm_nonneg _) (Finset.mem_univ i.succ)
    calc
      ‖x (i, j)‖ ≤ ‖v‖ := norm_le_pi_norm v j
      _ = ‖e.symm a‖ := by rw [e.symm_apply_apply]
      _ ≤ ‖e.symm.toContinuousLinearMap‖ * ‖a‖ :=
        e.symm.toContinuousLinearMap.le_opNorm _
      _ ≤ (‖e.symm.toContinuousLinearMap‖ + 1) *
          (∑ k, ∑ l, ‖vertices e x k - vertices e x l‖) := by gcongr; linarith
      _ = _ := by unfold meanDistance; change _ = _ * den * (_ / den); field_simp
  · intro x
    unfold meanDistance
    apply (div_le_iff₀ hden).2
    calc
      (∑ i, ∑ j, ‖vertices e x i - vertices e x j‖)
          ≤ ∑ _i : Fin (h + 1), ∑ _j : Fin (h + 1),
            (2 * (‖e.toContinuousLinearMap‖ + 1) * ‖x‖) := by
            apply Finset.sum_le_sum
            intro i _
            apply Finset.sum_le_sum
            intro j _
            refine (norm_sub_le _ _).trans ?_
            have hi := vertices_norm_le e x i
            have hj := vertices_norm_le e x j
            nlinarith [norm_nonneg x]
      _ = _ := by simp; field_simp
  · intro x y
    unfold meanDistance
    rw [← add_div]
    apply div_le_div_of_nonneg_right _ hden.le
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro i _
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro j _
    rw [vertices_add, vertices_add, add_sub_add_comm]
    exact norm_add_le _ _
  · intro t x ht
    unfold meanDistance
    simp_rw [vertices_smul, ← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_nonneg ht,
      ← Finset.mul_sum]
    ring

end PDDLimit
