import PDDLimit.Quantile
import PDDLimit.Average

namespace PDDLimit

open Filter MeasureTheory
open scoped Topology BigOperators

variable {ι : Type*} [Fintype ι]

noncomputable def shiftedCount {α : Type*} [Fintype α] (g : Gauge ι)
    (shift : α → ι → ℝ) (r : ℝ) : ℕ :=
  ∑ a, gridCount g (shift a) r

/-- The leading coefficients for finitely many disjoint motif shifts add. -/
theorem tendsto_shiftedCount {α : Type*} [Fintype α] (g : Gauge ι)
    (shift : α → ι → ℝ) :
    Tendsto (fun r : ℝ => (shiftedCount g shift r : ℝ) / r ^ Fintype.card ι) atTop
      (𝓝 ((Fintype.card α : ℝ) * (volume (sublevel g 1)).toReal)) := by
  classical
  have H := tendsto_finset_sum (s := (Finset.univ : Finset α))
    (fun a _ => tendsto_gridCount g (shift a))
  simpa only [shiftedCount, Nat.cast_sum, Finset.sum_div, Finset.sum_const,
    Finset.card_univ, nsmul_eq_mul] using H

/-- Deleting at most (O(r^e)) tuples with (e<d) preserves a count's
leading coefficient. -/
theorem tendsto_after_deleting {all kept : ℝ → ℕ} {d e : ℕ} (hed : e < d)
    {A C : ℝ}
    (hall : Tendsto (fun r : ℝ => (all r : ℝ) / r ^ d) atTop (𝓝 A))
    (hkept : ∀ᶠ r : ℝ in atTop, kept r ≤ all r)
    (hdelete : ∀ᶠ r : ℝ in atTop, (all r : ℝ) - kept r ≤ C * r ^ e) :
    Tendsto (fun r : ℝ => (kept r : ℝ) / r ^ d) atTop (𝓝 A) := by
  have hpow : Tendsto (fun r : ℝ => r ^ (d - e)) atTop atTop :=
    tendsto_pow_atTop (Nat.sub_ne_zero_of_lt hed)
  have hsmall := hpow.const_div_atTop C
  have hzero : Tendsto (fun r : ℝ => ((all r : ℝ) - kept r) / r ^ d) atTop (𝓝 0) := by
    refine tendsto_const_nhds.squeeze' hsmall ?_ ?_
    · filter_upwards [hkept, eventually_gt_atTop (0 : ℝ)] with r hr hp
      have hh : (kept r : ℝ) ≤ all r := by exact_mod_cast hr
      exact div_nonneg (sub_nonneg.mpr hh) (pow_nonneg hp.le _)
    · filter_upwards [hdelete, eventually_gt_atTop (0 : ℝ)] with r hr hp
      calc
        ((all r : ℝ) - kept r) / r ^ d ≤ (C * r ^ e) / r ^ d :=
          div_le_div_of_nonneg_right hr (pow_nonneg hp.le _)
        _ = C / r ^ (d - e) := by
          have heq : r ^ d = r ^ e * r ^ (d - e) := by
            rw [← pow_add, Nat.add_sub_of_le hed.le]
          rw [heq]
          field_simp
  convert hall.sub hzero using 1
  · ext r
    ring
  · rw [sub_zero]

/-- Averaging over the finite nonempty motif preserves the common limit. -/
theorem tendsto_motif_average {α : Type*} [Fintype α] [Nonempty α]
    (v : α → ℕ → ℝ) (c : ℝ) (hv : ∀ a, Tendsto (v a) atTop (𝓝 c)) :
    Tendsto (fun k => (∑ a, v a k) / (Fintype.card α : ℝ)) atTop (𝓝 c) := by
  classical
  have hh := tendsto_finset_sum (s := (Finset.univ : Finset α)) (fun a _ => hv a)
  have hc : (Fintype.card α : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  simpa [nsmul_eq_mul, hc] using hh.div_const (Fintype.card α : ℝ)

end PDDLimit
