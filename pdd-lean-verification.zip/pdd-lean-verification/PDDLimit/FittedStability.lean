import PDDLimit.Screening

namespace PDDLimit
namespace FittedPDA

open scoped BigOperators
open Screening

variable {I : Type*} [Fintype I]

def expect (w : I → ℝ) (f : I → ℝ) : ℝ := ∑ i, w i * f i

def energy (w : I → ℝ) (k : ℕ) (e : I → ℕ → ℝ) : ℝ :=
  ∑ j ∈ Finset.range k, expect w (fun i => (e i j) ^ 2)

def dotMean (w : I → ℝ) (k : ℕ) (b : ℕ → ℝ) (e : I → ℕ → ℝ) : ℝ :=
  ∑ j ∈ Finset.range k, b j * expect w (fun i => e i j)

def basisEnergy (k : ℕ) (b : ℕ → ℝ) : ℝ :=
  ∑ j ∈ Finset.range k, (b j) ^ 2

/-- For positive increasing predictors, the pointwise multiplier used in
the proof of Corollary 5.9(c) exceeds 1 at the final column. -/
theorem final_multiplier_gt_one (k : ℕ) (hk : 2 ≤ k) (b : ℕ → ℝ)
    (hpos : ∀ j < k, 0 < b j) (hb : StrictMono b) :
    1 < (∑ j ∈ Finset.range k, b j) / basisEnergy k b * b (k - 1) := by
  have h0 : 0 < k := by omega
  have hne : 0 ∈ Finset.range k := Finset.mem_range.mpr h0
  have hB : 0 < basisEnergy k b :=
    (sq_pos_of_pos (hpos 0 h0)).trans_le
      (Finset.single_le_sum (f := fun j => b j ^ 2) (fun j _ => sq_nonneg (b j)) hne)
  have hh : basisEnergy k b < ∑ j ∈ Finset.range k, b j * b (k - 1) := by
    unfold basisEnergy
    apply Finset.sum_lt_sum
    · intro j hj
      have h := Finset.mem_range.mp hj
      rw [pow_two]
      exact mul_le_mul_of_nonneg_left (hb.monotone (by omega)) (hpos j h).le
    · refine ⟨0,hne,?_⟩
      rw [pow_two]
      exact mul_lt_mul_of_pos_left (hb (by omega)) (hpos 0 h0)
  rw [div_mul_eq_mul_div₀, one_lt_div hB, Finset.sum_mul]
  exact hh

noncomputable def predictor (n h j : ℕ) : ℝ :=
  ((h.factorial * (j + 1) : ℕ) : ℝ) ^ (1 / ((n * h : ℕ) : ℝ))

theorem paper_final_multiplier_gt_one {n h k : ℕ} (hn : 0 < n) (hh : 0 < h) (hk : 2 ≤ k) :
    1 < (∑ j ∈ Finset.range k, predictor n h j) /
      basisEnergy k (predictor n h) * predictor n h (k - 1) := by
  apply final_multiplier_gt_one k hk
  · intro j _
    have hp : (0 : ℝ) < ((h.factorial * (j + 1) : ℕ) : ℝ) := by
      exact_mod_cast Nat.mul_pos (Nat.factorial_pos _) (Nat.succ_pos _)
    exact Real.rpow_pos_of_pos hp _
  · intro i j hij
    apply Real.rpow_lt_rpow (Nat.cast_nonneg _)
    · exact_mod_cast Nat.mul_lt_mul_of_pos_left (Nat.succ_lt_succ hij) (Nat.factorial_pos _)
    · exact one_div_pos.mpr (by exact_mod_cast Nat.mul_pos hn hh)

noncomputable def fit (w : I → ℝ) (k : ℕ) (b : ℕ → ℝ) (x : I → ℕ → ℝ) : ℝ :=
  dotMean w k b x / basisEnergy k b

def subtractFit (b : ℕ → ℝ) (t : ℝ) (x : I → ℕ → ℝ) : I → ℕ → ℝ :=
  fun i j => x i j - t * b j

private theorem square_shift (w : I → ℝ) (hw : ∑ i, w i = 1) (f : I → ℝ) (t : ℝ) :
    expect w (fun i => (f i - t) ^ 2) =
      expect w (fun i => (f i) ^ 2) - 2 * t * expect w f + t ^ 2 := by
  unfold expect
  calc
    _ = ∑ i, (w i * (f i) ^ 2 - (2 * t) * (w i * f i) + w i * t ^ 2) := by
      apply Finset.sum_congr rfl
      intro i _
      ring
    _ = _ := by
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum,
        ← Finset.sum_mul, hw, one_mul]

theorem energy_shift (w : I → ℝ) (hw : ∑ i, w i = 1) (k : ℕ)
    (b : ℕ → ℝ) (e : I → ℕ → ℝ) (t : ℝ) :
    energy w k (subtractFit b t e) =
      energy w k e - 2 * t * dotMean w k b e + t ^ 2 * basisEnergy k b := by
  unfold energy dotMean basisEnergy subtractFit
  calc
    _ = ∑ j ∈ Finset.range k,
        (expect w (fun i => (e i j) ^ 2) -
          (2 * t) * (b j * expect w (fun i => e i j)) + t ^ 2 * (b j) ^ 2) := by
      apply Finset.sum_congr rfl
      intro j _
      rw [square_shift w hw]
      ring
    _ = _ := by
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum]

/-- Completing the square identifies the same fitted coefficient from any
coupling with the specified marginals. -/
theorem fit_minimizes (w : I → ℝ) (hw : ∑ i, w i = 1) (k : ℕ)
    (b : ℕ → ℝ) (e : I → ℕ → ℝ) (hB : 0 < basisEnergy k b) (t : ℝ) :
    energy w k (subtractFit b (fit w k b e) e) ≤ energy w k (subtractFit b t e) := by
  have heq : fit w k b e * basisEnergy k b = dotMean w k b e :=
    div_mul_cancel₀ _ hB.ne'
  rw [energy_shift w hw, energy_shift w hw, ← heq]
  have h := mul_nonneg (sq_nonneg (t - fit w k b e)) hB.le
  nlinarith only [h]

theorem fit_scale_predictor (w : I → ℝ) (k : ℕ) (b : ℕ → ℝ) (e : I → ℕ → ℝ)
    (hB : 0 < basisEnergy k b) (a : ℝ) (ha : a ≠ 0) :
    fit w k (fun j => a * b j) e * a = fit w k b e := by
  have hd : dotMean w k (fun j => a * b j) e = a * dotMean w k b e := by
    simp only [dotMean, Finset.mul_sum, mul_assoc]
  have he : basisEnergy k (fun j => a * b j) = a ^ 2 * basisEnergy k b := by
    simp only [basisEnergy, mul_pow, Finset.mul_sum]
  unfold fit
  rw [hd,he]
  field_simp

theorem fittedEnergy_identity (w : I → ℝ) (hw : ∑ i, w i = 1) (k : ℕ)
    (b : ℕ → ℝ) (e : I → ℕ → ℝ) (hB : 0 < basisEnergy k b) :
    energy w k (subtractFit b (fit w k b e) e) =
      energy w k e - (fit w k b e) ^ 2 * basisEnergy k b := by
  have heq : fit w k b e * basisEnergy k b = dotMean w k b e :=
    div_mul_cancel₀ _ hB.ne'
  rw [energy_shift w hw, ← heq]
  ring

/-- New variant for refitted rows. Unnormalized squared cost, minimized in
the common baseline direction, is monotone under extending a prefix. -/
theorem refit_squared_prefix (w : I → ℝ) (hw : ∑ i, w i = 1)
    (hw₀ : ∀ i, 0 ≤ w i) (b : ℕ → ℝ) (e : I → ℕ → ℝ)
    {k K : ℕ} (hk : k ≤ K) (hB : 0 < basisEnergy k b) :
    energy w k (subtractFit b (fit w k b e) e) ≤
      energy w K (subtractFit b (fit w K b e) e) := by
  refine (fit_minimizes w hw k b e hB (fit w K b e)).trans ?_
  unfold energy
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hk) (fun _ _ _ =>
    Finset.sum_nonneg fun i _ => mul_nonneg (hw₀ i) (sq_nonneg _))

private theorem weighted_square (w : I → ℝ) (hw : ∑ i, w i = 1)
    (hw₀ : ∀ i, 0 ≤ w i) (f : I → ℝ) :
    (expect w f) ^ 2 ≤ expect w (fun i => (f i) ^ 2) := by
  have H := square_shift w hw f (expect w f)
  have hh : 0 ≤ expect w (fun i => (f i - expect w f) ^ 2) :=
    Finset.sum_nonneg fun i _ => mul_nonneg (hw₀ i) (sq_nonneg _)
  nlinarith only [H,hh]

/-- A coupling whose raw coordinate errors are each at most 2ε has average
fitted RMS cost at most 2ε, improving the paper's factor 4. -/
theorem fitted_rms_bound (w : I → ℝ) (hw : ∑ i, w i = 1) (hw₀ : ∀ i, 0 ≤ w i)
    (k : ℕ) (hk : 0 < k) (b : ℕ → ℝ) (e : I → ℕ → ℝ)
    (hB : 0 < basisEnergy k b) (ε : ℝ) (hε : 0 ≤ ε)
    (hraw : ∀ i j, 0 < w i → j < k → |e i j| ≤ 2 * ε) :
    expect w (fun i => rmsCost k (subtractFit b (fit w k b e) e i)) ≤ 2 * ε := by
  let t := fit w k b e
  let v := subtractFit b t e
  let f : I → ℝ := fun i => rmsCost k (v i)
  have hkr : 0 < (k : ℝ) := by exact_mod_cast hk
  have he : energy w k e ≤ (k : ℝ) * (2 * ε) ^ 2 := by
    calc
      _ ≤ ∑ _j ∈ Finset.range k, expect w (fun _ => (2 * ε) ^ 2) := by
        apply Finset.sum_le_sum
        intro j hj
        apply Finset.sum_le_sum
        intro i _
        rcases (hw₀ i).eq_or_lt with hz | hp
        · simp [← hz]
        apply mul_le_mul_of_nonneg_left _ (hw₀ i)
        have H := pow_le_pow_left₀ (abs_nonneg _) (hraw i j hp (Finset.mem_range.mp hj)) 2
        simpa only [sq_abs] using H
      _ = _ := by simp only [expect, ← Finset.sum_mul, hw, one_mul, Finset.sum_const,
        Finset.card_range, nsmul_eq_mul]
  have hv : energy w k v ≤ (k : ℝ) * (2 * ε) ^ 2 := by
    dsimp [v,t]
    rw [fittedEnergy_identity w hw k b e hB]
    exact (sub_le_self _ (mul_nonneg (sq_nonneg _) hB.le)).trans he
  have hf_i (i : I) : (f i) ^ 2 = (∑ j ∈ Finset.range k, (v i j) ^ 2) / k :=
    Real.sq_sqrt (div_nonneg (Finset.sum_nonneg fun _ _ => sq_nonneg _) hkr.le)
  have hf : expect w (fun i => (f i) ^ 2) = energy w k v / k := by
    unfold energy expect
    simp only [hf_i, ← mul_div_assoc, Finset.mul_sum, ← Finset.sum_div]
    rw [Finset.sum_comm]
  have H := weighted_square w hw hw₀ f
  rw [hf] at H
  have H' : (expect w f) ^ 2 ≤ (2 * ε) ^ 2 :=
    H.trans ((div_le_iff₀ hkr).2 (by simpa only [mul_comm] using hv))
  have Hε : 0 ≤ 2 * ε := by positivity
  exact le_of_not_gt (fun h => (not_lt_of_ge H')
    (pow_lt_pow_left₀ h Hε (by decide : (2 : ℕ) ≠ 0)))

section Coupling

variable {J : Type*} [Fintype J]

private def couplingWeight (p : I → J → ℝ) (ij : I × J) := p ij.1 ij.2

private def errorRows (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (ij : I × J) (j : ℕ) :=
  x ij.1 j - y ij.2 j

private theorem weights_total {w : I → ℝ} {z : J → ℝ} {p : I → J → ℝ}
    (hp : IsPlan w z p) (hw : ∑ i, w i = 1) :
    ∑ ij, couplingWeight p ij = 1 := by
  rw [Fintype.sum_prod_type]
  simpa only [couplingWeight, hp.2.1] using hw

private theorem fit_coupling {w : I → ℝ} {z : J → ℝ} {p : I → J → ℝ}
    (hp : IsPlan w z p) (k : ℕ) (b : ℕ → ℝ) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) :
    fit (couplingWeight p) k b (errorRows x y) = fit w k b x - fit z k b y := by
  have hm (j : ℕ) : expect (couplingWeight p) (fun ij => errorRows x y ij j) =
      expect w (fun i => x i j) - expect z (fun i => y i j) := by
    unfold expect
    simp only [Fintype.sum_prod_type, couplingWeight, errorRows, mul_sub, Finset.sum_sub_distrib]
    congr 1
    · simp only [← Finset.sum_mul, hp.2.1]
    · rw [Finset.sum_comm]
      simp only [← Finset.sum_mul, hp.2.2]
  unfold fit dotMean
  simp_rw [hm, mul_sub, Finset.sum_sub_distrib, sub_div]

noncomputable def fittedCost (k : ℕ) (b : ℕ → ℝ) (w : I → ℝ) (z : J → ℝ)
    (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (i : I) (j : J) : ℝ :=
  rmsCost k (fun col =>
    subtractFit b (fit w k b x) x i col - subtractFit b (fit z k b y) y j col)

private theorem cost_eq (k : ℕ) (b : ℕ → ℝ) {w : I → ℝ} {z : J → ℝ} {p : I → J → ℝ}
    (hp : IsPlan w z p) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (ij : I × J) :
    fittedCost k b w z x y ij.1 ij.2 = rmsCost k
      (subtractFit b (fit (couplingWeight p) k b (errorRows x y)) (errorRows x y) ij) := by
  unfold fittedCost
  rw [fit_coupling hp]
  congr 1
  funext l
  simp only [subtractFit, errorRows]
  ring

/-- Corollary 5.9's fitted RMS estimate, stated for the EMD infimum. The plan
can place zero mass on pairs that do not satisfy the perturbation bound. -/
theorem fitted_rms_transport_bound (k : ℕ) (hk : 0 < k) (b : ℕ → ℝ)
    (hB : 0 < basisEnergy k b) (w : I → ℝ) (z : J → ℝ) (hw : ∑ i, w i = 1)
    (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (ε : ℝ) (hε : 0 ≤ ε)
    (p : I → J → ℝ) (hp : IsPlan w z p)
    (hraw : ∀ i j l, 0 < p i j → l < k → |x i l - y j l| ≤ 2 * ε) :
    transport w z (fittedCost k b w z x y) ≤ 2 * ε := by
  have hc (i : I) (j : J) : 0 ≤ fittedCost k b w z x y i j := Real.sqrt_nonneg _
  refine (transport_le_plan hp hc).trans ?_
  have H := fitted_rms_bound (couplingWeight p) (weights_total hp hw)
    (fun ij => hp.1 ij.1 ij.2) k hk b (errorRows x y) hB ε hε
    (fun ij col h hc => hraw ij.1 ij.2 col h hc)
  simpa only [expect, ← cost_eq k b hp x y, Fintype.sum_prod_type, couplingWeight,
    planCost] using H

/-- The unnormalized squared Euclidean transport cost uses the same refitting
procedure, with the square moved inside the transport average. -/
noncomputable def fittedSquareCost (k : ℕ) (b : ℕ → ℝ) (w : I → ℝ) (z : J → ℝ)
    (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (i : I) (j : J) : ℝ :=
  ∑ l ∈ Finset.range k,
    (subtractFit b (fit w k b x) x i l - subtractFit b (fit z k b y) y j l) ^ 2

private theorem squared_plan_eq_energy {w : I → ℝ} {z : J → ℝ} {p : I → J → ℝ}
    (hp : IsPlan w z p) (k : ℕ) (b : ℕ → ℝ) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) :
    planCost p (fittedSquareCost k b w z x y) =
      energy (couplingWeight p) k
        (subtractFit b (fit (couplingWeight p) k b (errorRows x y)) (errorRows x y)) := by
  unfold planCost energy expect
  simp only [Fintype.sum_prod_type, couplingWeight, fittedSquareCost, Finset.mul_sum]
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  conv_rhs => rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  apply Finset.sum_congr rfl
  intro l _
  rw [fit_coupling hp]
  simp only [subtractFit, errorRows]
  ring

theorem refitted_squared_transport_prefix {k K : ℕ} (hk : k ≤ K)
    (b : ℕ → ℝ) (hB : 0 < basisEnergy k b)
    (w : I → ℝ) (z : J → ℝ) (hw : ∑ i, w i = 1)
    (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (hplan : ∃ p, IsPlan w z p) :
    transport w z (fittedSquareCost k b w z x y) ≤
      transport w z (fittedSquareCost K b w z x y) := by
  obtain ⟨p,hp⟩ := hplan
  have hn : {a : ℝ | ∃ q, IsPlan w z q ∧
    planCost q (fittedSquareCost K b w z x y) = a}.Nonempty := ⟨_,p,hp,rfl⟩
  apply le_csInf hn
  rintro _ ⟨q,hq,rfl⟩
  have hc (i : I) (j : J) : 0 ≤ fittedSquareCost k b w z x y i j :=
    Finset.sum_nonneg fun _ _ => sq_nonneg _
  refine (transport_le_plan hq hc).trans ?_
  rw [squared_plan_eq_energy hq, squared_plan_eq_energy hq]
  exact refit_squared_prefix _ (weights_total hq hw) (fun ij => hq.1 ij.1 ij.2) _ _ hk hB

end Coupling

end FittedPDA
end PDDLimit
