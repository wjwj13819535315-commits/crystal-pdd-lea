import Mathlib.Tactic
import Mathlib.Data.Real.Sqrt
import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace PDDLimit
namespace Screening

open scoped BigOperators

private theorem sum_prefix_mono {k K : ℕ} (hk : k ≤ K) (f : ℕ → ℝ)
    (hf : ∀ j, 0 ≤ f j) :
    (∑ j ∈ Finset.range k, f j) ≤ ∑ j ∈ Finset.range K, f j :=
  Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hk) (fun j _ _ => hf j)

/-- All rows share the same deterministic baseline for each structure and
order, regardless of how many columns are calculated. -/
def rowDiff (a b : ℕ → ℝ) (x y : ℕ → ℝ) (j : ℕ) :=
  (x j - a j) - (y j - b j)

noncomputable def lpCost (q : ℝ) (k : ℕ) (v : ℕ → ℝ) : ℝ :=
  (∑ j ∈ Finset.range k, |v j| ^ q) ^ (1 / q)

noncomputable def rmsCost (k : ℕ) (v : ℕ → ℝ) : ℝ :=
  Real.sqrt ((∑ j ∈ Finset.range k, (v j) ^ 2) / k)

noncomputable def supCost (k : ℕ) (v : ℕ → ℝ) : ℝ :=
  (insert 0 ((Finset.range k).image fun j => |v j|)).max' (by simp)

theorem abs_le_supCost {k j : ℕ} (hj : j < k) (v : ℕ → ℝ) :
    |v j| ≤ supCost k v := by
  classical
  unfold supCost
  apply Finset.le_max'
  exact Finset.mem_insert_of_mem (Finset.mem_image_of_mem _ (Finset.mem_range.mpr hj))

theorem supCost_le {k : ℕ} {B : ℝ} (hB : 0 ≤ B) (v : ℕ → ℝ)
    (h : ∀ j < k, |v j| ≤ B) : supCost k v ≤ B := by
  classical
  apply Finset.max'_le
  intro x hx
  rcases Finset.mem_insert.mp hx with rfl | hx
  · exact hB
  · obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hx
    exact h j (Finset.mem_range.mp hj)

theorem lpCost_prefix (q : ℝ) (hq : 0 < q) {k K : ℕ} (hk : k ≤ K) (v : ℕ → ℝ) :
    lpCost q k v ≤ lpCost q K v := by
  apply Real.rpow_le_rpow (Finset.sum_nonneg fun _ _ => Real.rpow_nonneg (abs_nonneg _) _)
  · exact sum_prefix_mono hk _ (fun _ => Real.rpow_nonneg (abs_nonneg _) _)
  · exact one_div_nonneg.mpr hq.le

theorem supCost_prefix {k K : ℕ} (hk : k ≤ K) (v : ℕ → ℝ) :
    supCost k v ≤ supCost K v := by
  classical
  unfold supCost
  apply Finset.max'_le
  intro a ha
  apply Finset.le_max'
  exact Finset.insert_subset_insert 0 (Finset.image_subset_image (Finset.range_mono hk)) ha

theorem rmsCost_prefix {k K : ℕ} (hk₀ : 0 < k) (hk : k ≤ K) (v : ℕ → ℝ) :
    Real.sqrt ((k : ℝ) / K) * rmsCost k v ≤ rmsCost K v := by
  have hk' : 0 < (k : ℝ) := by exact_mod_cast hk₀
  have hK' : 0 < (K : ℝ) := by exact_mod_cast hk₀.trans_le hk
  unfold rmsCost
  rw [← Real.sqrt_mul (div_nonneg hk'.le hK'.le)]
  apply Real.sqrt_le_sqrt
  rw [show (k : ℝ) / K * ((∑ j ∈ Finset.range k, (v j) ^ 2) / k) =
      (∑ j ∈ Finset.range k, (v j) ^ 2) / K by field_simp]
  exact div_le_div_of_nonneg_right (sum_prefix_mono hk _ (fun _ => sq_nonneg _)) hK'.le

section Transport

variable {I J : Type*} [Fintype I] [Fintype J]

def IsPlan (w : I → ℝ) (z : J → ℝ) (plan : I → J → ℝ) : Prop :=
  (∀ i j, 0 ≤ plan i j) ∧ (∀ i, ∑ j, plan i j = w i) ∧ (∀ j, ∑ i, plan i j = z j)

def planCost (plan : I → J → ℝ) (cost : I → J → ℝ) : ℝ :=
  ∑ i, ∑ j, plan i j * cost i j

noncomputable def transport (w : I → ℝ) (z : J → ℝ) (cost : I → J → ℝ) : ℝ :=
  sInf {a : ℝ | ∃ plan, IsPlan w z plan ∧ planCost plan cost = a}

theorem transport_le_plan {w : I → ℝ} {z : J → ℝ} {c : I → J → ℝ} {p : I → J → ℝ}
    (hp : IsPlan w z p) (hc : ∀ i j, 0 ≤ c i j) :
    transport w z c ≤ planCost p c := by
  have hb : BddBelow {a : ℝ | ∃ q, IsPlan w z q ∧ planCost q c = a} := by
    refine ⟨0, ?_⟩
    rintro _ ⟨q,hq,rfl⟩
    exact Finset.sum_nonneg fun i _ => Finset.sum_nonneg fun j _ =>
      mul_nonneg (hq.1 i j) (hc i j)
  exact csInf_le hb ⟨p,hp,rfl⟩

theorem transport_scale_le {w : I → ℝ} {z : J → ℝ} {c d : I → J → ℝ} {t : ℝ}
    (ht : 0 ≤ t) (hplan : ∃ plan, IsPlan w z plan) (hc : ∀ i j, 0 ≤ c i j)
    (hle : ∀ i j, t * c i j ≤ d i j) :
    t * transport w z c ≤ transport w z d := by
  obtain ⟨p, hp⟩ := hplan
  have hn : {a : ℝ | ∃ plan, IsPlan w z plan ∧ planCost plan d = a}.Nonempty :=
    ⟨planCost p d, p, hp, rfl⟩
  apply le_csInf hn
  rintro _ ⟨plan, hplan', rfl⟩
  refine (mul_le_mul_of_nonneg_left (transport_le_plan hplan' hc) ht).trans ?_
  unfold planCost
  simp only [Finset.mul_sum]
  exact Finset.sum_le_sum fun i _ => Finset.sum_le_sum fun j _ => by
    rw [mul_left_comm]
    exact mul_le_mul_of_nonneg_left (hle i j) (hplan'.1 i j)

theorem fixed_baseline_lp {w : I → ℝ} {z : J → ℝ} (hplan : ∃ plan, IsPlan w z plan)
    (a b : ℕ → ℝ) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ) (q : ℝ) (hq : 0 < q)
    {k K : ℕ} (hk : k ≤ K) :
    transport w z (fun i j => lpCost q k (rowDiff a b (x i) (y j))) ≤
      transport w z (fun i j => lpCost q K (rowDiff a b (x i) (y j))) := by
  have H := transport_scale_le (t := (1 : ℝ)) zero_le_one hplan
    (c := fun i j => lpCost q k (rowDiff a b (x i) (y j)))
    (fun _ _ => Real.rpow_nonneg (Finset.sum_nonneg fun _ _ =>
      Real.rpow_nonneg (abs_nonneg _) _) _)
    (d := fun i j => lpCost q K (rowDiff a b (x i) (y j)))
    (fun _ _ => by simpa only [one_mul] using lpCost_prefix q hq hk _)
  simpa only [one_mul] using H

theorem fixed_baseline_rms {w : I → ℝ} {z : J → ℝ} (hplan : ∃ plan, IsPlan w z plan)
    (a b : ℕ → ℝ) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ)
    {k K : ℕ} (hk₀ : 0 < k) (hk : k ≤ K) :
    Real.sqrt ((k : ℝ) / K) *
      transport w z (fun i j => rmsCost k (rowDiff a b (x i) (y j))) ≤
      transport w z (fun i j => rmsCost K (rowDiff a b (x i) (y j))) :=
  transport_scale_le (Real.sqrt_nonneg _) hplan (fun _ _ => Real.sqrt_nonneg _)
    (fun _ _ => rmsCost_prefix hk₀ hk _)

theorem fixed_baseline_sup {w : I → ℝ} {z : J → ℝ} (hplan : ∃ plan, IsPlan w z plan)
    (a b : ℕ → ℝ) (x : I → ℕ → ℝ) (y : J → ℕ → ℝ)
    {k K : ℕ} (hk : k ≤ K) :
    transport w z (fun i j => supCost k (rowDiff a b (x i) (y j))) ≤
      transport w z (fun i j => supCost K (rowDiff a b (x i) (y j))) := by
  classical
  have H := transport_scale_le (t := (1 : ℝ)) zero_le_one hplan
    (c := fun i j => supCost k (rowDiff a b (x i) (y j)))
    (fun _ _ => Finset.le_max' _ _ (Finset.mem_insert_self _ _))
    (d := fun i j => supCost K (rowDiff a b (x i) (y j)))
    (fun _ _ => by simpa only [one_mul] using supCost_prefix hk _)
  simpa only [one_mul] using H

end Transport

/-- The prefix bound passes to the joint descriptor's maximum over orders. -/
theorem joint_max_scale_le {k K : ℕ} (hk₀ : 0 < k) (hk : k ≤ K)
    (c d : ℕ → ℝ) {t : ℝ} (hle : ∀ j < k, t * c j ≤ d j) :
    t * (Finset.range k).sup' (Finset.nonempty_range_iff.mpr hk₀.ne') c ≤
      (Finset.range K).sup' (Finset.nonempty_range_iff.mpr (hk₀.trans_le hk).ne') d := by
  obtain ⟨j,hj,hmax⟩ := (Finset.range k).exists_mem_eq_sup'
    (Finset.nonempty_range_iff.mpr hk₀.ne') c
  rw [hmax]
  exact (hle j (Finset.mem_range.mp hj)).trans
    (Finset.le_sup' d (Finset.range_mono hk hj))

theorem single_row_transport (c : ℝ) :
    transport (fun _ : Unit => 1) (fun _ : Unit => 1) (fun _ _ => c) = c := by
  unfold transport
  have hs : {a : ℝ | ∃ p, IsPlan (fun _ : Unit => 1) (fun _ : Unit => 1) p ∧
      planCost p (fun _ _ => c) = a} = {c} := by
    ext a
    constructor
    · rintro ⟨p,hp,rfl⟩
      have h : p () () = 1 := by simpa using hp.2.1 ()
      simp [planCost, h]
    · intro h
      rcases Set.mem_singleton_iff.mp h with rfl
      exact ⟨fun _ _ => 1, ⟨fun _ _ => zero_le_one, by simp, by simp⟩, by simp [planCost]⟩
  rw [hs, csInf_singleton]

end Screening
end PDDLimit
