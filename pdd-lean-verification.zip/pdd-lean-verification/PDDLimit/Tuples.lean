import PDDLimit.Crystal
import Mathlib.Data.Fintype.Perm

namespace PDDLimit

open Filter MeasureTheory
open scoped Topology BigOperators

variable {n h : ℕ}

abbrev SiteKey (S : Crystal n) := (Fin n → ℤ) × S.motif

def point (S : Crystal n) (z : SiteKey S) : Fin n → ℝ := anchor z.2 z.1

theorem point_injective (S : Crystal n) : Function.Injective (point S) := by
  rintro ⟨z, p⟩ ⟨w, q⟩ heq
  have hf (r : S.motif) (i : Fin n) : ⌊(r : Fin n → ℝ) i⌋ = 0 := by
    have hr := S.motif_representatives r r.property i
    rw [Int.floor_eq_iff]
    simpa using hr
  have hz : z = w := by
    funext i
    have hi := congrArg (fun x : Fin n → ℝ => ⌊x i⌋) heq
    simpa [point, anchor, Int.floor_intCast_add, hf] using hi
  subst w
  congr 1
  apply Subtype.ext
  funext i
  exact add_left_cancel (congrFun heq i)

theorem range_point (S : Crystal n) : Set.range (point S) = sites S := by
  ext x
  constructor
  · rintro ⟨⟨z, p⟩, rfl⟩
    exact ⟨p, p.property, z, rfl⟩
  · rintro ⟨p, hp, z, rfl⟩
    exact ⟨(z, ⟨p, hp⟩), rfl⟩

noncomputable def tupleScore (S : Crystal n) (p : Fin n → ℝ) (x : Fin h → SiteKey S) : ℝ :=
  meanDistance S.embedding (fun ij => point S (x ij.1) ij.2 - p ij.2)

def candidates (S : Crystal n) (p : Fin n → ℝ) (h : ℕ) (r : ℝ) :
    Set (Fin h → SiteKey S) := {x | tupleScore S p x ≤ r}

def legal (S : Crystal n) (p : Fin n → ℝ) (x : Fin h → SiteKey S) : Prop :=
  Function.Injective x ∧ ∀ i, point S (x i) ≠ p

def legalCandidates (S : Crystal n) (p : Fin n → ℝ) (h : ℕ) (r : ℝ) :
    Set (Fin h → SiteKey S) := {x | x ∈ candidates S p h r ∧ legal S p x}

def tupleShift (S : Crystal n) (p : Fin n → ℝ) (m : Fin h → S.motif) :
    Fin h × Fin n → ℝ := fun ij => (m ij.1 : Fin n → ℝ) ij.2 - p ij.2

private def encode (S : Crystal n) :
    (Fin h → SiteKey S) ≃ ((Fin h → S.motif) × (Fin h × Fin n → ℤ)) where
  toFun x := (fun i => (x i).2, fun ij => (x ij.1).1 ij.2)
  invFun u i := (fun j => u.2 (i,j), u.1 i)
  left_inv x := by funext i; rfl
  right_inv u := by rcases u with ⟨m,z⟩; congr 1

private def GridIndex (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h)
    (r : ℝ) (m : Fin h → S.motif) : Type :=
  {z : Fin h × Fin n → ℤ | anchor (tupleShift S p m) z ∈
    sublevel (distanceGauge S.embedding hh) r}

private noncomputable instance gridIndexFintype (S : Crystal n) (p : Fin n → ℝ)
    (hh : 0 < h) (r : ℝ) (m : Fin h → S.motif) : Fintype (GridIndex S p hh r m) :=
  (grid_finite (distanceGauge S.embedding hh) (tupleShift S p m) r).fintype

private def candidateEquiv (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) (r : ℝ) :
    candidates S p h r ≃ Σ m, GridIndex S p hh r m where
  toFun x := ⟨(encode S x.1).1, (encode S x.1).2, by
    have hx : tupleScore S p x.1 ≤ r := x.property
    change meanDistance S.embedding (anchor (tupleShift S p _) _) ≤ r
    convert hx using 2
    unfold tupleScore
    apply congrArg (meanDistance S.embedding)
    funext ij
    change ((x.1 ij.1).1 ij.2 : ℝ) + ((x.1 ij.1).2.val ij.2 - p ij.2) =
      ((x.1 ij.1).1 ij.2 : ℝ) + (x.1 ij.1).2.val ij.2 - p ij.2
    ring⟩
  invFun z := ⟨(encode S).symm (z.1, z.2.val), by
    have hz : meanDistance S.embedding (anchor (tupleShift S p z.1) z.2.val) ≤ r :=
      z.2.property
    change tupleScore S p ((encode S).symm (z.1, z.2.val)) ≤ r
    convert hz using 2
    unfold tupleScore
    apply congrArg (meanDistance S.embedding)
    funext ij
    change (z.2.val ij : ℝ) + (z.1 ij.1).val ij.2 - p ij.2 =
      (z.2.val ij : ℝ) + ((z.1 ij.1).val ij.2 - p ij.2)
    ring⟩
  left_inv x := by apply Subtype.ext; exact (encode S).symm_apply_apply x.1
  right_inv z := by rcases z with ⟨m, z, hz⟩; rfl

theorem candidates_finite (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) (r : ℝ) :
    (candidates S p h r).Finite := by
  letI : Finite (candidates S p h r) := Finite.of_equiv _ (candidateEquiv S p hh r).symm
  exact Set.toFinite _

theorem candidates_ncard (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) (r : ℝ) :
    (candidates S p h r).ncard = allTuples S p hh r := by
  classical
  letI := (candidates_finite S p hh r).fintype
  rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card, Fintype.card_congr (candidateEquiv S p hh r),
    Fintype.card_sigma]
  unfold allTuples shiftedCount
  apply Finset.sum_congr rfl
  intro m _
  exact (@Set.Finite.card_toFinset _ _ (gridIndexFintype S p hh r m)
    (grid_finite (distanceGauge S.embedding hh) (tupleShift S p m) r)).symm

private noncomputable def pointEquiv (S : Crystal n) : SiteKey S ≃ sites S :=
  (Equiv.ofInjective (point S) (point_injective S)).trans
    (Equiv.setCongr (range_point S))

private noncomputable def perSelection (S : Crystal n) (p : Fin n → ℝ) (r : ℝ)
    (A : selections S p h r) (f : Fin h ≃ A.val) : Fin h → SiteKey S :=
  fun i => (pointEquiv S).symm ⟨f i, A.property.2.2.1 (f i).property⟩

private theorem point_perSelection (S : Crystal n) (p : Fin n → ℝ) (r : ℝ)
    (A : selections S p h r) (f : Fin h ≃ A.val) (i : Fin h) :
    point S (perSelection S p r A f i) = (f i : Fin n → ℝ) :=
  congrArg Subtype.val ((pointEquiv S).apply_symm_apply _)

private theorem score_eq_of_enumerations (S : Crystal n) (p : Fin n → ℝ)
    (A : Finset (Fin n → ℝ)) (f g : Fin h ≃ A) :
    meanDistance S.embedding (fun ij : Fin h × Fin n => (g ij.1).val ij.2 - p ij.2) =
      meanDistance S.embedding (fun ij : Fin h × Fin n => (f ij.1).val ij.2 - p ij.2) := by
  let π : Equiv.Perm (Fin h) := g.trans f.symm
  let x : Fin h × Fin n → ℝ := fun ij => (f ij.1).val ij.2 - p ij.2
  have hπ (i : Fin h) : f (π i) = g i := f.apply_symm_apply (g i)
  have hx : (fun ij : Fin h × Fin n => (g ij.1).val ij.2 - p ij.2) =
      (fun ij : Fin h × Fin n => x (π ij.1, ij.2)) := by
    funext ij
    exact congrArg (fun z : A => z.val ij.2 - p ij.2) (hπ ij.1).symm
  rw [hx]
  exact meanDistance_reindex S.embedding x π

private noncomputable def selectionToLegal (S : Crystal n) (p : Fin n → ℝ) (r : ℝ)
    (a : Σ A : selections S p h r, Fin h ≃ A.val) : legalCandidates S p h r :=
  ⟨perSelection S p r a.1 a.2, by
    constructor
    · obtain ⟨f, hf⟩ := a.1.property.2.2.2
      have hscore : tupleScore S p (perSelection S p r a.1 a.2) =
          meanDistance S.embedding (fun ij : Fin h × Fin n =>
            (f ij.1 : Fin n → ℝ) ij.2 - p ij.2) := by
        unfold tupleScore
        simp_rw [point_perSelection]
        exact score_eq_of_enumerations S p a.1.val f a.2
      exact hscore.le.trans hf
    · constructor
      · intro i j hij
        apply a.2.injective
        apply Subtype.ext
        simpa only [point_perSelection] using congrArg (point S) hij
      · intro i hi
        exact a.1.property.1 (by
          rw [point_perSelection] at hi
          exact Eq.mp (congrArg (fun q : Fin n → ℝ => q ∈ a.1.val) hi)
            (a.2 i).property)⟩

private theorem selectionToLegal_injective (S : Crystal n) (p : Fin n → ℝ) (r : ℝ) :
    Function.Injective (@selectionToLegal n h S p r) := by
  classical
  rintro ⟨A,f⟩ ⟨B,g⟩ heq
  have hp (i : Fin h) : (f i : Fin n → ℝ) = (g i : Fin n → ℝ) := by
    have hi := congrArg (fun x : legalCandidates S p h r => point S (x.val i)) heq
    simpa only [selectionToLegal, point_perSelection] using hi
  have hAB : A = B := by
    apply Subtype.ext
    ext x
    constructor
    · intro hx
      obtain ⟨i, hi⟩ := f.surjective ⟨x, hx⟩
      have hs : (g i : Fin n → ℝ) = x := (hp i).symm.trans (congrArg Subtype.val hi)
      exact hs ▸ (g i).property
    · intro hx
      obtain ⟨i, hi⟩ := g.surjective ⟨x, hx⟩
      have hs : (f i : Fin n → ℝ) = x := (hp i).trans (congrArg Subtype.val hi)
      exact hs ▸ (f i).property
  subst B
  congr 1
  apply Equiv.ext
  intro i
  exact Subtype.ext (hp i)

private theorem selectionToLegal_surjective (S : Crystal n) (p : Fin n → ℝ) (r : ℝ) :
    Function.Surjective (@selectionToLegal n h S p r) := by
  classical
  intro x
  let A := Finset.univ.image (fun i => point S (x.val i))
  have hinj : Function.Injective (fun i => point S (x.val i)) :=
    (point_injective S).comp x.property.2.1
  have hm (i : Fin h) : point S (x.val i) ∈ A := Finset.mem_image_of_mem _ (Finset.mem_univ _)
  let f : Fin h ≃ A := Equiv.ofBijective (fun i => ⟨point S (x.val i), hm i⟩) ⟨
    fun _ _ eq => hinj (congrArg Subtype.val eq), by
      intro y
      obtain ⟨i, _, hi⟩ := Finset.mem_image.mp y.property
      exact ⟨i, Subtype.ext hi⟩⟩
  have hA : A ∈ selections S p h r := by
    refine ⟨?_, ?_, ?_, f, x.property.1⟩
    · intro hp
      obtain ⟨i, _, hi⟩ := Finset.mem_image.mp hp
      exact x.property.2.2 i hi
    · simpa using (Fintype.card_congr f).symm
    · intro y hy
      change y ∈ A at hy
      obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hy
      rw [← range_point]
      exact ⟨_, rfl⟩
  refine ⟨⟨⟨A,hA⟩,f⟩, Subtype.ext (funext fun i => ?_)⟩
  apply point_injective S
  exact point_perSelection S p r ⟨A,hA⟩ f i

private noncomputable def selectionEquiv (S : Crystal n) (p : Fin n → ℝ) (r : ℝ) :
    (Σ A : selections S p h r, Fin h ≃ A.val) ≃ legalCandidates S p h r :=
  Equiv.ofBijective (selectionToLegal S p r)
    ⟨selectionToLegal_injective S p r, selectionToLegal_surjective S p r⟩

theorem selections_finite (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) (r : ℝ) :
    (selections S p h r).Finite := by
  letI : Finite (legalCandidates S p h r) :=
    (candidates_finite S p hh r).subset
      (show legalCandidates S p h r ⊆ candidates S p h r from fun _ hx => hx.1)
  letI : Finite (Σ A : selections S p h r, Fin h ≃ A.val) :=
    Finite.of_equiv _ (selectionEquiv S p r).symm
  letI : Finite (selections S p h r) := Finite.of_surjective Sigma.fst (by
    intro A
    obtain ⟨f, _⟩ := A.property.2.2.2
    exact ⟨⟨A, f⟩, rfl⟩)
  exact Set.toFinite _

theorem selectionCount_monotone (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) :
    Monotone (selectionCount S p h) := by
  intro r s hrs
  apply Set.ncard_le_ncard _ (selections_finite S p hh s)
  intro A hA
  obtain ⟨h₁, h₂, h₃, f, h₄⟩ := hA
  exact ⟨h₁, h₂, h₃, f, h₄.trans hrs⟩

theorem legalCandidates_ncard (S : Crystal n) (p : Fin n → ℝ) (hh : 0 < h) (r : ℝ) :
    (legalCandidates S p h r).ncard = h.factorial * selectionCount S p h r := by
  classical
  letI := ((candidates_finite S p hh r).subset
    (show legalCandidates S p h r ⊆ candidates S p h r from fun _ hx => hx.1)).fintype
  letI := (selections_finite S p hh r).fintype
  rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card,
    Fintype.card_congr (selectionEquiv S p r).symm, Fintype.card_sigma,
    selectionCount, ← Nat.card_coe_set_eq, Nat.card_eq_fintype_card]
  have hc (A : selections S p h r) : Fintype.card (Fin h ≃ A.val) = h.factorial := by
    let f := Classical.choose A.property.2.2.2
    rw [Fintype.card_congr (Equiv.equivCongr (Equiv.refl (Fin h)) f.symm), Fintype.card_perm]
    simp
  simp [hc, Nat.mul_comm]

end PDDLimit
